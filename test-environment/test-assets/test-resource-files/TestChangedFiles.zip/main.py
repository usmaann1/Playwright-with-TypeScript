from PIL import Image, ImageDraw, ImageFont

# Create a new image with RGB mode and purple background
img = Image.new('RGB', (400, 300), 'purple')

# Initialize ImageDraw to draw on the image
draw = ImageDraw.Draw(img)

# Draw a rectangle with a specific outline color
draw.rectangle([(50, 50), (350, 250)], outline="white", width=5)

# Define font (this path might need to be adjusted for your environment)
# For a simple example, we'll not use an external font file
# font = ImageFont.truetype("arial.ttf", size=45)

# Draw text (using a simple built-in font)
draw.text((100, 100), "Hello, World!", fill="white")

# Save the image to a file
img.save('./generated_image.jpg')

print("Image has been created and saved.")
