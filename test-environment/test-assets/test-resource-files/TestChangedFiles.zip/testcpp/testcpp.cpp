#include <iostream>

int main()
{
    std::cout << "this is a test";
}