namespace Helpers
{
    public class Helper
    {
        public string Greet(string name)
        {
            return "this is a " + name;
        }
    }
}