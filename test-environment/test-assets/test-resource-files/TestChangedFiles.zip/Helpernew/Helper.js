class Helper {
    greet(name) {
        return `this is a ${name}`;
    }
}