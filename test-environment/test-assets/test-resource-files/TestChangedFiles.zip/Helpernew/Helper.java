// Helper/Helper.java
package Helper;

public class Helper {
    public String getTestMessage() {
        return "this is a test";
    }
}
