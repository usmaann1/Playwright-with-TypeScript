public class TestNot
{    public static void main(String[] args)
   {
     boolean homeworkDone = false;
     if (!homeworkDone)
     {
         System.out.println("Sorry, you can't go out!");
     }
   }
}
