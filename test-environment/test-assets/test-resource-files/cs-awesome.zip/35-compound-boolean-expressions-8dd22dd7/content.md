 ![](https://www.codingrooms.com/images/courses/csawesome/_images/time90.png ",,NaN")

# 3.5. Compound Boolean Expressions

## 3.5.1. And (&&), Or (||), and Not (!)

\
What if you want two things to be true before the body of the conditional is executed? Use `&&` as a logical **and** to join two Boolean expressions and the body of the condition will only be executed only if both are true.

\
 ![coding exercise](https://www.codingrooms.com/images/courses/csawesome/_images/codingExercise.png "left-icon,,NaN") **Coding Exercise**

What if you want to go out and your parents say you can go out if you clean your room and do your homework? Run the code below and try different values for `cleanedRoom` and `didHomework` and see what they have to be for it to print `You can go out`.

\
[https://www.codingrooms.com/block/ide/eb7febe4-04d5-4152-9488-c1c9f83f70dd](https://www.codingrooms.com/block/ide/eb7febe4-04d5-4152-9488-c1c9f83f70dd)

\
\
What if it is okay if only one of two things is true? Use `||` as a logical **or** to join two Boolean expressions and the body of the condition will be executed if one or both are true.

\
 ![coding exercise](https://www.codingrooms.com/images/courses/csawesome/_images/codingExercise.png "left-icon,,NaN") **Coding Exercise**

For example, your parents might say you can go out if you can walk or they don’t need the car. Try different values for `walking` and `carIsAvailable` and see what the values have to be to print `You can go out`.

\
[https://www.codingrooms.com/block/ide/9099b682-c577-4403-82a5-10f1d5422b6d](https://www.codingrooms.com/block/ide/9099b682-c577-4403-82a5-10f1d5422b6d)

\
\

:::tip 
Note

In English, we often use an exclusive-or like in the sentence “do you want to be player 1 *or* player 2?” where you can’t be both player 1 and player 2. In programming, the or-operator is an inclusive-or which means that the whole expression is true if either one or the other or *both* conditions are true.

:::

\
\
With numerical values, the **or** (||) operator is often used to check for error conditions on different ends of the number line, while the **and** (&&) operator is often used to see if a number is in an range.

\
 ![coding exercise](https://www.codingrooms.com/images/courses/csawesome/_images/codingExercise.png "left-icon,,NaN") **Coding Exercise**

Explore how && and || are used with numbers below. Try different values for score like -10 and 110 in the code below.

\
[https://www.codingrooms.com/block/ide/01baf3c8-b1d8-406f-80e9-47d22ff1d170](https://www.codingrooms.com/block/ide/01baf3c8-b1d8-406f-80e9-47d22ff1d170)

\
\
The **not** (!) operator can be used to negate a boolean value. We’ve seen ! before in != (not equal). If you use ! in expressions with && and ||, be careful because the results are often the opposite of what you think it will be at first. We’ll see examples of this in the next lesson.

\
 ![coding exercise](https://www.codingrooms.com/images/courses/csawesome/_images/codingExercise.png "left-icon,,NaN") **Coding Exercise**

The code below says if homework is not done, you can’t go out. Try different values for `homeworkDone`.

\
[https://www.codingrooms.com/block/ide/a9ff0493-81f4-4738-99fa-47b1c78a2070](https://www.codingrooms.com/block/ide/a9ff0493-81f4-4738-99fa-47b1c78a2070)

\
\

:::tip 
Note

In Java, ! will be executed before &&, and && will be executed before ||, unless there are parentheses. Anything inside parentheses is executed first.

:::

\
## 3.5.2. Truth Tables

\
The following table (also called a **truth table**) shows the result for P && Q when P and Q are both expressions that can be true or false. An expression involving logical operators like (P && Q) evaluates to a Boolean value, true or false. As you can see below the result of P && Q is only true if both P and Q are true.

| P | Q | P && Q |
|----|----|----|
| true | true | true |
| --- | --- | --- |
| false | true | false |
| true | false | ? |
| false | false | false |

\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") **Check your understanding**

\
[https://www.codingrooms.com/block/blank/4075378c-b452-40ce-b64f-e7b550456487](https://www.codingrooms.com/block/blank/4075378c-b452-40ce-b64f-e7b550456487)

\
\
The following table shows the result for P || Q when P and Q are both expressions that can be true or false. As you can see below the result of P || Q is true if either P or Q is true. It is also true when both of them are true.

| P | Q | P || Q |
| --- | --- | --- |

| true | true | true |
|----|----|----|
| false | true | ? |
| true | false | true |
| false | false | false |

\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") **Check your understanding**

\
[https://www.codingrooms.com/block/blank/72699aa1-7612-4ed3-8190-f7d24b04dc08](https://www.codingrooms.com/block/blank/72699aa1-7612-4ed3-8190-f7d24b04dc08)

\
\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") **Check your understanding**

\
[https://www.codingrooms.com/block/mc/261cb709-265e-4f21-98d4-b0ed62dc9a60](https://www.codingrooms.com/block/mc/261cb709-265e-4f21-98d4-b0ed62dc9a60)

\
\
[https://www.codingrooms.com/block/mc/42260104-4a44-476f-83ce-8a6b0b1349a4](https://www.codingrooms.com/block/mc/42260104-4a44-476f-83ce-8a6b0b1349a4)

\
\
[https://www.codingrooms.com/block/mc/b537f037-d3e6-4596-b46b-a3b0ade2578d](https://www.codingrooms.com/block/mc/b537f037-d3e6-4596-b46b-a3b0ade2578d)

\
## 3.5.3. Short Circuit Evaluation

\
Both `&&` and `||` use **short circuit evaluation**. That means that the second expression (on the right of the operator) isn’t necessarily checked, if the result from the first expression is enough to tell if the compound boolean expression is true or false:

* If two boolean values/expressions are combined with a logical **or** (||) and the first expression is true, then the second expression won’t be executed, since only one needs to be true for the result to be true.
* If two boolean values/expressions are combined with a logical **and** (&&) and the first expression is false, then the second expression won’t be executed. If the first expression is false, the result will be false, since both sides of the && need to be true for the result to be true.

\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") **Check your understanding**

\
[https://www.codingrooms.com/block/mc/47c9b490-3806-4c89-8551-84adcbdbc16c](https://www.codingrooms.com/block/mc/47c9b490-3806-4c89-8551-84adcbdbc16c)

\
\
[https://www.codingrooms.com/block/mc/b3dc9e8e-baa8-405c-a88a-46352a8fcd81](https://www.codingrooms.com/block/mc/b3dc9e8e-baa8-405c-a88a-46352a8fcd81)

\
## 3.5.4.  ![groupwork](https://www.codingrooms.com/images/courses/csawesome/_images/groupwork.png "left-icon,,NaN") Programming Challenge : Truth Tables POGIL

\
We encourage you to do this activity as a [POGIL](https://pogil.org/about-pogil/what-is-pogil) (Process Oriented Guided Inquiry Learning) group activity. POGIL groups are self-managed teams of up to 4 students where everyone has a [POGIL role](https://docs.google.com/document/d/1_NfNLWJxaG4qZ2Jd2x8UctDS05twn1h6p-o3XaAcRv0/edit?usp=sharing) and works together to solve the problems, making sure that everyone in the team participates and learns.

\
Explore the following problems with your group:

1. Draw or print a [Venn diagram](https://docs.google.com/document/d/1lpjk0LS_KdAddRurMayJZmaFzeyEg4FyhviZcSTXvtU/edit?usp=sharing) of 4 intersecting circles. Put the names of the 4 people in your group one in each circle. Write down the age of each person in your group in the circles. If two or more people are the same age, put the age in the intersecting parts of their circles. Write a Boolean expression that compares the age of each person in the group using ==, <, >, and &&, for example Ada’s age > Alan’s age && Alan’s age == Grace’s age. Then, ask each person in your group their favorite movie. If two or more people have the same favorite movie, put the movie in the intersecting parts of their circles. Write a Boolean expression that compares the favorite movies in the group using ==, !=, and &&, for example Ada’s movie == Alan’s movie && Alan’s movie != Grace’s movie. Think of 1 more comparison and write it in the circles and as a Boolean expression. Share the Boolean expressions with the class. (Thank you to Jill Westerlund of Hoover High School and Art Lopez of Sweetwater High School for this activity suggestion).
2. Write the sentence “If it’s sunny, OR if the temperature is greater than 80 and it’s not raining, I will go to the beach.” as a Java if statement using an int variable `temperature` and boolean variables `sunny` and `raining`. If the conditional is true, print out “Go to the beach!”. So, you will go to the beach on days that it is sunny in any temperature, or you will go to the beach on days when the temperature is over 80 degrees and it’s not raining.
3. Complete a truth table for the if statement that you wrote in #2 with columns for sunny, temperature > 80, raining, and go to the beach.
4. Write Java code below to test your if statement and try all the values in your truth table to see if you filled it out correctly. You will need test case for each of the 8 rows in your truth table, for example when sunny is true and false, when raining is true or false, and for a value of temperature greater than 80, for example 90, and less than 80, for example 60.

Challenge-3-5-truthtables: Test your boolean expression in an if statement below.

\
[https://www.codingrooms.com/block/ide/fb348c83-74d1-4973-b373-50d01f7cd34e](https://www.codingrooms.com/block/ide/fb348c83-74d1-4973-b373-50d01f7cd34e)

\
## 3.5.5. Summary

* Logical operators `!` (not), `&&` (and), and `||` (or) are used with Boolean values.
* `(A && B)` is true if both A and B are true.
* `(A || B)` is true if either A or B (or both) are true.
* `!(A)` is true if A is false.
* In Java, `!` has precedence (is executed before) `&&` which has precedence over `||`. Parentheses can be used to force the order of execution in a different way.
* When the result of a logical expression using `&&` or `||` can be determined by evaluating only the first Boolean operand, the second is not evaluated. This is known as **short-circuit evaluation**.

## 3.5.6. AP Practice

\
[https://www.codingrooms.com/block/mc/94b87f0d-b0c1-4045-a9ee-a22a01155373](https://www.codingrooms.com/block/mc/94b87f0d-b0c1-4045-a9ee-a22a01155373)

\
## 3.5.7. Boolean Game

\
Try the game below written to practice Booleans. Click on **Booleans**, look at the color and number in the block and evaluate the boolean expression to choose true or false. Then, check on Compound for an added challenge. We encourage you to work in pairs and see how high a score you can get.

\
[https://www.codingrooms.com/block/embed/ace2e10d-57d8-49c9-8b79-e8b0a23d9c08](https://www.codingrooms.com/block/embed/ace2e10d-57d8-49c9-8b79-e8b0a23d9c08)

\
