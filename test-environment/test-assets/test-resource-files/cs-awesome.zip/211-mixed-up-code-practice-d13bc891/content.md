# 2.11. Mixed Up Code Practice

\
Try to solve each of the following mixed-up code problems or try the experimental switch between mixed up or write code versions of these problems on the next page instead.

\
For these mixed up code problems, drag the blocks into the correct order. Click the *Check Me* button to check each solution. You will be told if your solution is too short, has a block in the wrong order, or you are using the wrong block. Some of the problems may have an extra block that isn’t needed in the correct solution. After 3 tries, you can ask for help and some of the blocks will be combined. You can solve these on your phone or other mobile device!

\
[https://www.codingrooms.com/block/parsons/ed80a954-f2ce-4b25-a41f-d69f9d498210](https://www.codingrooms.com/block/parsons/ed80a954-f2ce-4b25-a41f-d69f9d498210)

\
\
[https://www.codingrooms.com/block/parsons/4ee2de7d-ce85-4c9e-9abe-77e915ef3097](https://www.codingrooms.com/block/parsons/4ee2de7d-ce85-4c9e-9abe-77e915ef3097)

\
\
[https://www.codingrooms.com/block/parsons/42ee4e66-928d-4e07-bb5f-1039b7dc35ac](https://www.codingrooms.com/block/parsons/42ee4e66-928d-4e07-bb5f-1039b7dc35ac)

\
\
[https://www.codingrooms.com/block/parsons/ef3ea00d-82a9-46ae-a317-b8ebe6f70d8c](https://www.codingrooms.com/block/parsons/ef3ea00d-82a9-46ae-a317-b8ebe6f70d8c)

\
\
[https://www.codingrooms.com/block/parsons/89f13651-ac4a-484a-986a-a3b4689f3e68](https://www.codingrooms.com/block/parsons/89f13651-ac4a-484a-986a-a3b4689f3e68)

\
\
[https://www.codingrooms.com/block/parsons/df1eb7bf-745a-4981-bc07-87b50d7287f7](https://www.codingrooms.com/block/parsons/df1eb7bf-745a-4981-bc07-87b50d7287f7)

\
