public class Test1
{
    public static void main(String[] args)
    {
        int x = -3;
        if (x > 0)
            System.out.println("x is less than 0");

    }

}
