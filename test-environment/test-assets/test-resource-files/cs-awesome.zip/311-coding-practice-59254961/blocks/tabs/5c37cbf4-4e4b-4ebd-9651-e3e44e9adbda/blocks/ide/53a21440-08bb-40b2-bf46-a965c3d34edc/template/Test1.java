public class Test1
{
    public static void main(String[] args)
    {
        boolean haveHomework = false;
        boolean didDishes = true;

    }
}
