public class Test1
{
    public static void main(String[] args)
    {
        boolean haveHomework = false;
        boolean didDishes = true;
        if (!haveHomework && didDishes)
            System.out.println("You can go out");
        else
            System.out.println("You can't go out");

    }
}
