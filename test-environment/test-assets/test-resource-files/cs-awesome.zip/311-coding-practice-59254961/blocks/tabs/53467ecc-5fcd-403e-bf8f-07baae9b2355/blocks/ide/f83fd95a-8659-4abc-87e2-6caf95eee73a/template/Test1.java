public class Test1
{
    public static void main(String[] args)
    {
        double temp = 103.5;
        if (temp > 100)
            System.out.println("You have a fever");
        else
            System.out.println("You don't have a fever");
    }
}
