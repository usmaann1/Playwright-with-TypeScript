public class Test1
{
    public static void main(String[] args)
    {
        int score = 67;

    }
}
