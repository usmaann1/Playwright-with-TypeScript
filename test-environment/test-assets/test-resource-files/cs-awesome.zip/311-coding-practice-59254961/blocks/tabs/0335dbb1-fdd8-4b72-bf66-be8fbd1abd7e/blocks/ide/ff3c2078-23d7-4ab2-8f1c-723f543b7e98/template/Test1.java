public class Test1
{
    public static void main(String[] args)
    {
        int score = 67;
        if (score >= 92)
            System.out.println("A");
        else if (score >= 82)
            System.out.println("B");
        else if (score >= 72)
            System.out.println("C");
        else if (score >= 62)
            System.out.println("D");
        else
            System.out.println("E");

    }
}
