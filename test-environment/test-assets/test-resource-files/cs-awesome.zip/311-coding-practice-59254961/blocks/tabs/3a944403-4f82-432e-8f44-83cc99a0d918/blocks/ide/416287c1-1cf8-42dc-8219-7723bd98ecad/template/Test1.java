public class Test1
{
    public static void main(String[] args)
    {
        int x = 3;
        if (x >= 0 && x <= 10)
            System.out.println("x is between 0 and 10 inclusive");
        else
            System.out.println("x is either less than 0 or greater than 10");
    }
}
