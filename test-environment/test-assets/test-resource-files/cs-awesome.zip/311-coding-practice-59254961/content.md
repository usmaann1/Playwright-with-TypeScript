# 3.11. Coding Practice

\
[https://www.codingrooms.com/block/tabs/97a99833-995d-4b0d-a73f-3362048aecba](https://www.codingrooms.com/block/tabs/97a99833-995d-4b0d-a73f-3362048aecba)

\
\
[https://www.codingrooms.com/block/tabs/05880930-9a68-4df1-a5c8-3f3c2bf9bbed](https://www.codingrooms.com/block/tabs/05880930-9a68-4df1-a5c8-3f3c2bf9bbed)

\
\
[https://www.codingrooms.com/block/tabs/b09ef1d9-34c0-41d8-9003-7f675d18babf](https://www.codingrooms.com/block/tabs/b09ef1d9-34c0-41d8-9003-7f675d18babf)

\
\
[https://www.codingrooms.com/block/tabs/3a944403-4f82-432e-8f44-83cc99a0d918](https://www.codingrooms.com/block/tabs/3a944403-4f82-432e-8f44-83cc99a0d918)

\
\
[https://www.codingrooms.com/block/tabs/1645520a-00f8-4ce7-9d2e-9117eccbf9f7](https://www.codingrooms.com/block/tabs/1645520a-00f8-4ce7-9d2e-9117eccbf9f7)

\
\
[https://www.codingrooms.com/block/tabs/65a1b356-4821-4b76-a38a-6122a044d5ee](https://www.codingrooms.com/block/tabs/65a1b356-4821-4b76-a38a-6122a044d5ee)

\
\
[https://www.codingrooms.com/block/tabs/5c37cbf4-4e4b-4ebd-9651-e3e44e9adbda](https://www.codingrooms.com/block/tabs/5c37cbf4-4e4b-4ebd-9651-e3e44e9adbda)

\
\
[https://www.codingrooms.com/block/tabs/53467ecc-5fcd-403e-bf8f-07baae9b2355](https://www.codingrooms.com/block/tabs/53467ecc-5fcd-403e-bf8f-07baae9b2355)

\
\
[https://www.codingrooms.com/block/tabs/c5a14777-2d40-442c-bac9-fe687d5d7213](https://www.codingrooms.com/block/tabs/c5a14777-2d40-442c-bac9-fe687d5d7213)

\
\
[https://www.codingrooms.com/block/tabs/0335dbb1-fdd8-4b72-bf66-be8fbd1abd7e](https://www.codingrooms.com/block/tabs/0335dbb1-fdd8-4b72-bf66-be8fbd1abd7e)

\
\
For more practice with conditionals, and especially complex conditionals, go to <http://codingbat.com/java/Logic-1> and <http://codingbat.com/java/Logic-2>

\
In particular we recommend solving the following problems

* <http://codingbat.com/prob/p118290>
* <http://codingbat.com/prob/p183071>
* <http://codingbat.com/prob/p110973>
* <http://codingbat.com/prob/p103360>
* <http://codingbat.com/prob/p169213>
* <http://codingbat.com/prob/p178728>
* <http://codingbat.com/prob/p115233>