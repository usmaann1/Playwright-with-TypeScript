import java.util.*;
import java.awt.*;

public class TurtleTest
{
  public static void main(String[] args)
  {
      World habitat = new World(300,300);
      Turtle t1 = new Turtle(habitat);

      habitat.show(true);
  }
}
