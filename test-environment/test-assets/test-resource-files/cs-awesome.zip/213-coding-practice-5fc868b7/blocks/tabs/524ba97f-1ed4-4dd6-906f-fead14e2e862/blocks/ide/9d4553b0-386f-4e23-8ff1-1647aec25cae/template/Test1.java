public class Test1
{
    public static void main(String[] args)
    {
        String message = "That was great - lol.";

    }
}
