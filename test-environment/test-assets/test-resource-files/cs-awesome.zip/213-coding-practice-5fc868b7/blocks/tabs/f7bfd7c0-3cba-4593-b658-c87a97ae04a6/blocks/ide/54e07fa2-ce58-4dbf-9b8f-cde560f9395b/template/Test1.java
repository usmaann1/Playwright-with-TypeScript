public class Test1
{
    public static void main(String[] args)
    {
        String name1 = "ALEX";



        System.out.println(firstNameCaps);
    }
}
