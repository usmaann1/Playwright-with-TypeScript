public class Test1
{
    public static void main(String[] args)
    {
        String message = "Meet me by the bridge";
        String part = message.substring(0,3);
        String lower = part.toLowerCase();
        System.out.println(lower);
    }
}
