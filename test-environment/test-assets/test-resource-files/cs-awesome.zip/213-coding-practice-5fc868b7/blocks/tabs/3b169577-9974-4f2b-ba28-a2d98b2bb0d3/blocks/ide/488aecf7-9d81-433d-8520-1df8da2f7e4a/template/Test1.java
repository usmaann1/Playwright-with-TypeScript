public class Test1
{
    public static void main(String[] args)
    {
        String message = "Meet me by the bridge":
        String part = message.substring(1,3);
        String lower = message.toLowerCase();
        System.println(lower);
    }
}
