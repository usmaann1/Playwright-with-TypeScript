# 2.13. Coding Practice

\
[https://www.codingrooms.com/block/tabs/978f5b3c-2ca9-4d16-b192-4309182f90df](https://www.codingrooms.com/block/tabs/978f5b3c-2ca9-4d16-b192-4309182f90df)

\
\
[https://www.codingrooms.com/block/tabs/0cdb2818-b52a-493c-ac93-e26c41bde10d](https://www.codingrooms.com/block/tabs/0cdb2818-b52a-493c-ac93-e26c41bde10d)

\
\
[https://www.codingrooms.com/block/tabs/3b169577-9974-4f2b-ba28-a2d98b2bb0d3](https://www.codingrooms.com/block/tabs/3b169577-9974-4f2b-ba28-a2d98b2bb0d3)

\
\
[https://www.codingrooms.com/block/tabs/f7bfd7c0-3cba-4593-b658-c87a97ae04a6](https://www.codingrooms.com/block/tabs/f7bfd7c0-3cba-4593-b658-c87a97ae04a6)

\
\
[https://www.codingrooms.com/block/tabs/045f55a4-a12c-4569-940d-da1e5fbbd0e8](https://www.codingrooms.com/block/tabs/045f55a4-a12c-4569-940d-da1e5fbbd0e8)

\
\
[https://www.codingrooms.com/block/tabs/524ba97f-1ed4-4dd6-906f-fead14e2e862](https://www.codingrooms.com/block/tabs/524ba97f-1ed4-4dd6-906f-fead14e2e862)

\
\
For more practice with Strings see problems at <http://codingbat.com/java/String-1>.

* <http://codingbat.com/prob/p161056>
* <http://codingbat.com/prob/p147483>
* <http://codingbat.com/prob/p108853>
* <http://codingbat.com/prob/p130896>
* <http://codingbat.com/prob/p130781>

\
Here are some practice coding problems for Turtles.

Finish the code below to have `t1` draw a triangle where all of the sides are length 50.

\
[https://www.codingrooms.com/block/ide/92b26519-e860-4dd0-afcf-9bab21ff6479](https://www.codingrooms.com/block/ide/92b26519-e860-4dd0-afcf-9bab21ff6479)

\
Finish the code below to have `t1` draw a rectangle. The vertical sides should be length 50 and the horizontal length 100.

\
[https://www.codingrooms.com/block/ide/f0f088f7-399d-4a15-a31a-d689779cf9de](https://www.codingrooms.com/block/ide/f0f088f7-399d-4a15-a31a-d689779cf9de)

\
Finish the code below to have `t1` draw the number seven.

\
[https://www.codingrooms.com/block/ide/bdce345e-c7c6-41dc-a535-7829a211bb6f](https://www.codingrooms.com/block/ide/bdce345e-c7c6-41dc-a535-7829a211bb6f)

\
Finish the code below to have `t1` draw the number four.

\
[https://www.codingrooms.com/block/ide/e9caffcb-2119-4353-9b42-6a857b52b454](https://www.codingrooms.com/block/ide/e9caffcb-2119-4353-9b42-6a857b52b454)

\
Finish the code below to have `t1` draw something interesting.

\
[https://www.codingrooms.com/block/ide/2b14e726-5055-40ca-99cc-4f20573a165e](https://www.codingrooms.com/block/ide/2b14e726-5055-40ca-99cc-4f20573a165e)

\
