public class BatteryTest
{
    public static void main(String[] args)
    {
        int battery = 60;

        System.out.println("All okay!");
    }
}
