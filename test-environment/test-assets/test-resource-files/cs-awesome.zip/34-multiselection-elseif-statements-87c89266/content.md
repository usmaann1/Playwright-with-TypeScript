 ![](https://www.codingrooms.com/images/courses/csawesome/_images/time90.png ",,NaN")

# 3.4. Multi-Selection: else-if Statements

\
Using if/else statements, you can even pick between 3 or more possibilites. Just add **else if** for each possibility after the first **if**, and **else** before the last possibility.

```java
// 3 way choice with else if
if (boolean expression)
{
   statement1;
}
else if (boolean expression)
{
   statement2;
}
else
{
   statement3;
}
```

\
 ![coding exercise](https://www.codingrooms.com/images/courses/csawesome/_images/codingExercise.png "left-icon,,NaN") **Coding Exercise**

Run the code below and try changing the value of x to get each of the three possible lines in the conditional to print.

\
[https://www.codingrooms.com/block/ide/5b26f55d-ed83-4554-87d7-ec10e7b56166](https://www.codingrooms.com/block/ide/5b26f55d-ed83-4554-87d7-ec10e7b56166)

\
\
Here is a flowchart for a conditional with 3 options like in the code above.

 ![](https://www.codingrooms.com/images/courses/csawesome/_images/Condition-three.png ",,NaN")

Figure 1: The order that statements execute in a conditional with 3 options: if, else if, and else

\

:::tip 
Note

Another way to handle 3 or more conditional cases is to use the `switch` and `break` keywords, but these will not be on the exam. For a tutorial on using switch see <https://docs.oracle.com/javase/tutorial/java/nutsandbolts/switch.html>.

:::

\
\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") **Check your understanding**

\
[https://www.codingrooms.com/block/mc/8ae0ccd3-1c3e-4dfd-a2d7-061572c30b80](https://www.codingrooms.com/block/mc/8ae0ccd3-1c3e-4dfd-a2d7-061572c30b80)

\
\
[https://www.codingrooms.com/block/mc/2544f91e-1ecb-4e86-ac58-a55f073abb97](https://www.codingrooms.com/block/mc/2544f91e-1ecb-4e86-ac58-a55f073abb97)

\
\
[https://www.codingrooms.com/block/mc/fbe3d656-74b9-488c-b322-3b5df1cb94e1](https://www.codingrooms.com/block/mc/fbe3d656-74b9-488c-b322-3b5df1cb94e1)

\
\
 ![coding exercise](https://www.codingrooms.com/images/courses/csawesome/_images/codingExercise.png "left-icon,,NaN") **Coding Exercise**

The else-if connection is necessary if you want to hook up conditionals together. In the following code, there are 4 separate if statements instead of the if-else-if pattern. Will this code print out the correct grade? First, trace through the code to see why it prints out the incorrect grade. Use the Code Lens button. Then, fix the code by adding in 3 else’s to connect the if statements and see if it works.

\
[https://www.codingrooms.com/block/ide/d25579e8-39eb-41ed-876b-11fe15df3ce0](https://www.codingrooms.com/block/ide/d25579e8-39eb-41ed-876b-11fe15df3ce0)

\
Finish the following code so that it prints “Plug in your phone!” if the battery is below 50, “Unplug your phone!” if it is above 100, and “All okay!” otherwise. Change the battery value to test all 3 conditions.

\
[https://www.codingrooms.com/block/ide/78f9836c-cbd1-4a19-a876-853275f53b55](https://www.codingrooms.com/block/ide/78f9836c-cbd1-4a19-a876-853275f53b55)

\
## 3.4.1.  ![groupwork](https://www.codingrooms.com/images/courses/csawesome/_images/groupwork.png "left-icon,,NaN") Programming Challenge : Adventure

 ![Adventure map](https://www.codingrooms.com/images/courses/csawesome/_images/adventure.jpg ",,NaN")

\
We encourage you to work in pairs for this challenge.

\
One of the first games coded for early computers in the 1970s was called [Colossal Cave Adventure](https://en.wikipedia.org/wiki/Colossal_Cave_Adventure). It was a text-based interactive fiction game where you had to make your way through an elaborate cave. The program only understood one word or phrase commands like north, south, enter, take, etc. You can try [playing Adventure](http://www.web-adventures.org/cgi-bin/webfrotz?s=Adventure) recreated online following some of the commands in this [walkthrough](http://www.sierrahelp.com/Walkthroughs/AdventureWalkthrough.html#in). Part of the challenge is finding the commands that the code will understand.

\
In a game like Adventure, else if statements can be used to respond to commands from the user like n, s, e, w.

1. Try the program below. This is a very simple adventure game that lets the user move in 4 different directions. Right now, it only lets the user move north.
2. Add in **else if** statements to go in the directions of “s” for south, “e” for east, “w” for west, and an else statement that says “You can’t go in that direction”. Be creative and come up with different situations in each direction.
3. How many test-cases are needed to test all branches of your code?
4. If your class has time, your teacher may ask you to expand this game further or to come up with a different adventure location.

This is an interactive version of the challenge where you can develop and test your code.

\
[https://www.codingrooms.com/block/ide/25dbdf18-c58b-46ef-ba20-12055a539507](https://www.codingrooms.com/block/ide/25dbdf18-c58b-46ef-ba20-12055a539507)

\
Copy and paste your all of your code from the interactive version above and run to see if it passes the autograder tests. Note that this code will only run with the autograder’s input and will not ask the user for input.

\
[https://www.codingrooms.com/block/ide/b1ebc39a-622f-45de-a08a-7f82ef0f1e6d](https://www.codingrooms.com/block/ide/b1ebc39a-622f-45de-a08a-7f82ef0f1e6d)

\
## 3.4.2. Summary

* A multi-way selection is written when there are a series of conditions with different statements for each condition.
* Multi-way selection is performed using if-else-if statements such that exactly one section of code is executed based on the first condition that evaluates to true.

```java
// 3 way choice with else if
if (boolean expression)
{
   statement1;
}
else if (boolean expression)
{
   statement2;
}
else
{
    statement3;
}
```

## 3.4.3. AP Practice

\
[https://www.codingrooms.com/block/mc/069eaee1-a5e5-43a7-88b2-a2f8d82013f1](https://www.codingrooms.com/block/mc/069eaee1-a5e5-43a7-88b2-a2f8d82013f1)

\
