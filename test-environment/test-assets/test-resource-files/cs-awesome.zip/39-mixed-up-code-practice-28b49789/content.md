# 3.9. Mixed Up Code Practice

\
Try to solve each of the following. Click the *Check Me* button to check each solution. You will be told if your solution is too short, has a block in the wrong order, or you are using the wrong block. Some of the problems have an extra block or two that aren’t needed in the correct solution. Try to solve these on your phone or other mobile device!

\
[https://www.codingrooms.com/block/parsons/cd2d4431-edd4-4b58-8833-d07f2b7f0fe5](https://www.codingrooms.com/block/parsons/cd2d4431-edd4-4b58-8833-d07f2b7f0fe5)

\
\
[https://www.codingrooms.com/block/parsons/94cdfcbc-9463-4c94-bd3a-4d1880d424a0](https://www.codingrooms.com/block/parsons/94cdfcbc-9463-4c94-bd3a-4d1880d424a0)

\
\
[https://www.codingrooms.com/block/parsons/61f2cb4a-9655-4181-bcca-875199036fe2](https://www.codingrooms.com/block/parsons/61f2cb4a-9655-4181-bcca-875199036fe2)

\
\
[https://www.codingrooms.com/block/parsons/c8e54b5c-9b06-4b8c-813a-80bed0e9bd9d](https://www.codingrooms.com/block/parsons/c8e54b5c-9b06-4b8c-813a-80bed0e9bd9d)

\
\
[https://www.codingrooms.com/block/parsons/3cd5771c-2792-48a8-8cc5-8539e8492c4d](https://www.codingrooms.com/block/parsons/3cd5771c-2792-48a8-8cc5-8539e8492c4d)

\
\
[https://www.codingrooms.com/block/parsons/6b09dff0-a1c6-47b1-8a46-7416719b2c7f](https://www.codingrooms.com/block/parsons/6b09dff0-a1c6-47b1-8a46-7416719b2c7f)

\
\
[https://www.codingrooms.com/block/parsons/135f0646-fef0-4840-bdd2-aec8e234ecbf](https://www.codingrooms.com/block/parsons/135f0646-fef0-4840-bdd2-aec8e234ecbf)

\
\
[https://www.codingrooms.com/block/parsons/77bd7d1d-c75b-4b83-922e-4f1094c76f5d](https://www.codingrooms.com/block/parsons/77bd7d1d-c75b-4b83-922e-4f1094c76f5d)

\
\
[https://www.codingrooms.com/block/parsons/a5a75f6f-c202-43b3-b0e9-a7cfe2b782f6](https://www.codingrooms.com/block/parsons/a5a75f6f-c202-43b3-b0e9-a7cfe2b782f6)

\
\
[https://www.codingrooms.com/block/parsons/e89852cf-3362-4b36-962a-57a3e61d7530](https://www.codingrooms.com/block/parsons/e89852cf-3362-4b36-962a-57a3e61d7530)

\
