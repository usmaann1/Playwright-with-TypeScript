# 3.10. Toggle Mixed Up or Write Code Practice

> For each of the problems below, if you need help, you can pull down the toggle menu to choose the associated mixed up code problem to help you get started.

\
For the mixed up code problems, drag the blocks into the correct order. Click the *Check Me* button to check each solution. You will be told if your solution is too short, has a block in the wrong order, or you are using the wrong block. Some of the problems may have an extra block that isn’t needed in the correct solution. After 3 tries, you can ask for help and some of the blocks will be combined. You can solve these on your phone or other mobile device!

\
[https://www.codingrooms.com/block/tabs/60b84a8c-48bc-4e0e-8cc9-37064db939bb](https://www.codingrooms.com/block/tabs/60b84a8c-48bc-4e0e-8cc9-37064db939bb)

\
\
[https://www.codingrooms.com/block/tabs/05ef3529-1177-40bf-9e3f-515661aa52ff](https://www.codingrooms.com/block/tabs/05ef3529-1177-40bf-9e3f-515661aa52ff)

\
\
[https://www.codingrooms.com/block/tabs/77174a9b-3024-43b7-a636-fdccd978343c](https://www.codingrooms.com/block/tabs/77174a9b-3024-43b7-a636-fdccd978343c)

\
\
[https://www.codingrooms.com/block/tabs/4e0a7c96-1004-4334-b914-9584ebb0b231](https://www.codingrooms.com/block/tabs/4e0a7c96-1004-4334-b914-9584ebb0b231)

\
\
[https://www.codingrooms.com/block/tabs/52509f93-8d7e-40cd-b667-186f85738254](https://www.codingrooms.com/block/tabs/52509f93-8d7e-40cd-b667-186f85738254)

\
\
[https://www.codingrooms.com/block/tabs/c6f8e297-cd80-4dcf-82ff-0f3f5a5129c6](https://www.codingrooms.com/block/tabs/c6f8e297-cd80-4dcf-82ff-0f3f5a5129c6)

\
\
[https://www.codingrooms.com/block/tabs/73e7d97b-927d-4ea6-bd24-37034f3acd4d](https://www.codingrooms.com/block/tabs/73e7d97b-927d-4ea6-bd24-37034f3acd4d)

\
\
[https://www.codingrooms.com/block/tabs/83311166-c797-4eea-85a9-95491e474568](https://www.codingrooms.com/block/tabs/83311166-c797-4eea-85a9-95491e474568)

\
\
[https://www.codingrooms.com/block/tabs/01995c8c-a9b0-4c29-9f61-e48332b204ce](https://www.codingrooms.com/block/tabs/01995c8c-a9b0-4c29-9f61-e48332b204ce)

\
\
[https://www.codingrooms.com/block/tabs/80088233-d996-4d35-b186-c2b5e4030e0b](https://www.codingrooms.com/block/tabs/80088233-d996-4d35-b186-c2b5e4030e0b)

\
