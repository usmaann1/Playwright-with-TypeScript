public class Test1
{
    public static void main(String[] args)
    {
        int speed = 90;
        // Add your code here
    }
}
