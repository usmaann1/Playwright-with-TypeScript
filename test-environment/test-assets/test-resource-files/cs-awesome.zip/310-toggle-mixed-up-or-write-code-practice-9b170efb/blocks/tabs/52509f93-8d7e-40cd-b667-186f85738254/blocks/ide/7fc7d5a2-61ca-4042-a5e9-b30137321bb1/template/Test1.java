public class Test1
{
    public static void main(String[] args)
    {
        String favFood = "kale";
        // Add your code here

    }
}
