public class Test1
{
    public static void main(String[] args)
    {
       boolean weekend = false;
       // Add your code here
    }
}
