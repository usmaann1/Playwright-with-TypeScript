public class Test1
{
   public static void main(String[] args)
   {
       String message = "Is that the phone ringing?";
       // Add your code here

   }
}
