public class Test1
{
    public static void main(String[] args)
    {
        boolean driving = true;
        boolean eating = false;
        // Add your code here
    }
}
