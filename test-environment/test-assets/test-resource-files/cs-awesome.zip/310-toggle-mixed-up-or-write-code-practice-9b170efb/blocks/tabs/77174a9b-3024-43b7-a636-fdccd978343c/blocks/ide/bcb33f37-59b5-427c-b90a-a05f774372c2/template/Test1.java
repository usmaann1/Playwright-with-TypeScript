public class Test1
{
    public static void main(String[] args)
    {
       int x = 3;

       // Add your code here


    }
}
