public class Test1
{
    public static void main(String[] args)
    {
        String name = "Julian";
        String firstLetter = name.substring(0,1);
        String lowerFirst = firstLetter.toLowerCase();

        // Add your code here
    }
}
