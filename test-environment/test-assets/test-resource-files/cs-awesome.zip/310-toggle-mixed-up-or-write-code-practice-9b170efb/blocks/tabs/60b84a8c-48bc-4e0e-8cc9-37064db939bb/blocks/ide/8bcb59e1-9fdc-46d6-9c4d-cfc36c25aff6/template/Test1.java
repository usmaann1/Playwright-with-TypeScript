public class Test1
{
    public static void main(String[] args)
    {
        int guess = 10;
        int answer = 5;

        // Add your code here


    }
 }
 