public class Test1
{
    public static void main(String[] args)
    {
       boolean homeworkLeft = false;
       boolean cleaned = true;
       // Add your code here


    }
}
