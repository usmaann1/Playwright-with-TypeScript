# 2.14. Practice Test for Objects (2.1-2.5)

\
The following 10 questions are similar to what you might see on the AP CS A exam for Units 2.1-2.5.

\
We estimate that a score of about 50% on this test would correspond to the passing grade of 3 on the AP exam, a score of 65% to a 4, and a score of 80% and above to a 5 on the AP exam. These are just estimates and may not correspond to individual scores.

\
[https://www.codingrooms.com/block/mc/731c4add-09d8-4cc7-8534-3d9b8c58e193](https://www.codingrooms.com/block/mc/731c4add-09d8-4cc7-8534-3d9b8c58e193)

\
\
[https://www.codingrooms.com/block/mc/99d3eadc-9f1b-4eb9-9a4b-0e68c483591d](https://www.codingrooms.com/block/mc/99d3eadc-9f1b-4eb9-9a4b-0e68c483591d)

\
\
[https://www.codingrooms.com/block/mc/a65d7ec8-4261-4dd9-80a5-c54767ec4a84](https://www.codingrooms.com/block/mc/a65d7ec8-4261-4dd9-80a5-c54767ec4a84)

\
\
[https://www.codingrooms.com/block/mc/f00e1f57-dd84-4a61-a544-c93a333eccfd](https://www.codingrooms.com/block/mc/f00e1f57-dd84-4a61-a544-c93a333eccfd)

\
\
[https://www.codingrooms.com/block/mc/03bcb5f2-a3fd-48e7-a882-297a65a69cfa](https://www.codingrooms.com/block/mc/03bcb5f2-a3fd-48e7-a882-297a65a69cfa)

\
\
[https://www.codingrooms.com/block/mc/7b160b4b-1b52-433e-b22f-95ee8dd5ce43](https://www.codingrooms.com/block/mc/7b160b4b-1b52-433e-b22f-95ee8dd5ce43)

\
\
[https://www.codingrooms.com/block/mc/2d59e2cb-ef8a-4791-8ddc-16257ff6f6e4](https://www.codingrooms.com/block/mc/2d59e2cb-ef8a-4791-8ddc-16257ff6f6e4)

\
\
[https://www.codingrooms.com/block/mc/ffe0652e-3b3b-41ed-a624-053a39371aa0](https://www.codingrooms.com/block/mc/ffe0652e-3b3b-41ed-a624-053a39371aa0)

\
\
[https://www.codingrooms.com/block/mc/11a1f1e1-50a0-43d8-b1fc-55d3ba29f1a3](https://www.codingrooms.com/block/mc/11a1f1e1-50a0-43d8-b1fc-55d3ba29f1a3)

\
\
[https://www.codingrooms.com/block/mc/50a722c6-ca1e-4f3d-aff2-d602d2f2f0bd](https://www.codingrooms.com/block/mc/50a722c6-ca1e-4f3d-aff2-d602d2f2f0bd)

\
