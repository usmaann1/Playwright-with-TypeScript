 ![](https://www.codingrooms.com/images/courses/csawesome/_images/time90.png ",,NaN")

# 3.3. Two-way Selection: if-else Statements

\
What if you want to pick between two possibilities? If you are trying to decide between a couple of things to do, you might flip a coin and do one thing if it lands as heads and another if it is tails. In programming, you can use the **if** keyword followed by a statement or block of statements and then the **else** keyword also followed by a statement or block of statements.

```java
// A block if/else statement
if (boolean expression)
{
   statement1;
   statement2;
}
else
{
   do other statement;
   and another one;
}
```

```java
// A single if/else statement
if (boolean expression)
    Do statement;
else
    Do other statement;
```

\
The following flowchart demonstrates that if the condition (the boolean expression) is true, one block of statements is executed, but if the condition is false, a different block of statements inside the else clause is executed.

 ![](https://www.codingrooms.com/images/courses/csawesome/_images/Condition-two.png ",,NaN")

Figure 1: The order that statements execute in a conditional with 2 options: if and else

\

:::tip 
Note

The else will only execute if the condition is false.

:::

\
Try the following code. If `isHeads` is true it will print `Let's go to the game` and then `after conditional`.

\
[https://www.codingrooms.com/block/ide/86c4fff0-2598-4791-a600-ddcc09ff5962](https://www.codingrooms.com/block/ide/86c4fff0-2598-4791-a600-ddcc09ff5962)

\
\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") **Check your understanding**

\
[https://www.codingrooms.com/block/blank/7180fcd4-a9da-4317-900c-0aea38a1979b](https://www.codingrooms.com/block/blank/7180fcd4-a9da-4317-900c-0aea38a1979b)

\
\
If/else statements can also be used with relational operators and numbers like below. If your code has an if/else statement, you need to test it with 2 test-cases to make sure that both parts of the code work.

\
 ![coding exercise](https://www.codingrooms.com/images/courses/csawesome/_images/codingExercise.png "left-icon,,NaN") **Coding Exercise**

Run the following code to see what it prints out when the variable age is set to the value 16. Change the variable age’s value to 15 and then run it again to see the result of the print statement in the else part. Can you change the if-statement to indicate that you can get a license at age 15 instead of 16? Use 2 test cases for the value of age to test your code to see the results of both print statements.

\
[https://www.codingrooms.com/block/ide/995c2892-bb2f-4c61-8b80-d8c29155819b](https://www.codingrooms.com/block/ide/995c2892-bb2f-4c61-8b80-d8c29155819b)

\
\
[https://www.codingrooms.com/block/parsons/8929ff7d-0003-4d47-acf8-01154c95485e](https://www.codingrooms.com/block/parsons/8929ff7d-0003-4d47-acf8-01154c95485e)

\
\
 ![coding exercise](https://www.codingrooms.com/images/courses/csawesome/_images/codingExercise.png "left-icon,,NaN") **Coding Exercise**

Try the following code. Add an else statement to the if statement that prints out “Good job!” if the score is greater than 9. Change the value of score to test it. Can you change the boolean test to only print out “Good job” if the score is greater than 20?

\
[https://www.codingrooms.com/block/ide/b7944e24-11ac-444e-a2f5-1a67e76c824b](https://www.codingrooms.com/block/ide/b7944e24-11ac-444e-a2f5-1a67e76c824b)

\
## 3.3.1. Nested Ifs and Dangling Else

\
If statements can be nested inside other if statements. Sometimes with nested ifs we find a **dangling else** that could potentially belong to either if statement. The rule is that the else clause will always be a part of the closest unmatched if statement in the same block of code, regardless of indentation.

```java
// Nested if with dangling else
if (boolean expression)
   if (boolean expression)
      Do statement;
   else  // belongs to closest if
      Do other statement;
```

\
 ![coding exercise](https://www.codingrooms.com/images/courses/csawesome/_images/codingExercise.png "left-icon,,NaN") **Coding Exercise**

Try the following code with a dangling else. Notice that the indentation does not matter to the compiler (but you should make it your habit to use good indentation just as a best practice). How could you get the else to belong to the first if statement?

\
[https://www.codingrooms.com/block/ide/4f587f4d-c390-45e8-8265-9cd27ad44a5e](https://www.codingrooms.com/block/ide/4f587f4d-c390-45e8-8265-9cd27ad44a5e)

\
\
You can use curly brackets { } to enclose a nested if and have the else clause belong to the the top level if clause like below:

```java
// Nested if with dangling else
if (boolean expression)
{
   if (boolean expression)
      Do this statement;
}
else  // belongs to first if
  Do that statement;
```

## 3.3.2.  ![groupwork](https://www.codingrooms.com/images/courses/csawesome/_images/groupwork.png "left-icon,,NaN") Programming Challenge : 20 Questions

 ![](https://www.codingrooms.com/images/courses/csawesome/_images/questionmark.jpg ",,NaN")

\
We encourage you to work in pairs for this challenge.

\
Have you ever played 20 Questions? 20 Questions is a game where one person thinks of an object and the other players ask up to 20 questions to guess what it is.

\
There is great online version called [Akinator](https://en.akinator.com/) that guesses whether you are thinking of a real or fictional character by asking you questions. Akinator is a simple Artificial Intelligence algorithm that uses a decision tree of yes or no questions to pinpoint the answer. Although Akinator needs a very large decision tree, we can create a guessing game for animals using a much smaller number of if-statements.

\
The Animal Guessing program below uses the following decision tree:

 ![](https://www.codingrooms.com/images/courses/csawesome/_images/decision-tree.png ",,NaN")

Figure 2: Animal Guessing Game Decision Tree

1. Try the interactive Animal Guessing program below and run it a couple times thinking of an animal and answering the questions with y or n for yes or no. Did it guess your animal? Probably not! It’s not very good. It can only guess 3 animals. Let’s try to expand it!

This is an interactive demo using the Scanner class.

\
[https://www.codingrooms.com/block/ide/f42b5d1a-2bd6-4078-bc9c-a06546a0fbbb](https://www.codingrooms.com/block/ide/f42b5d1a-2bd6-4078-bc9c-a06546a0fbbb)

\
2. In the very last else clause, the program knows that it is not a mammal and it guesses a bird. Let’s add to that part. Instead of saying “I guess a bird! Click on run to play again.”, change it to ask a question that distinguishes between birds and reptiles (for example does it fly?). Then, get their response and use an if statement to guess “bird” or “turtle” (or another reptile). For example, here’s how we decided to choose between a dog or an elephant. We asked the question “Is it a pet?”, got the response, and then with an if statement on the y/n answer we determined dog or elephant. You would use similar code to distinguish between a bird and a turtle. Run your code and test both possibilities!

```java
System.out.println("Is it a pet (y/n)?");
answer = scan.nextLine();
if (answer.equals("y")) {
     System.out.println("I guess a dog! Click on run to play again.");
 }
 else {
     System.out.println("I guess an elephant! Click on run to play again.");
 }
```

3. Did you notice that when it asked “Is it a pet?” and you said “y”, it immediately guessed “dog”? What if you were thinking of a cat? Try to come up with a question that distinguishes dogs from cats and put in code in the correct place (in place of the code that prints out “I guess a dog”) to ask the question, get the answer, and use an if/else to guess cat or dog. Run your code and test both possibilities!
4. How many animals can your game now guess? How many test-cases are needed to test all branches of your code?
5. If your class has time, your teacher may ask you to expand this game or to create a similar game to guess something else like singers or athletes. Spend some time planning your questions on paper and drawing out the decision tree before coding it.

Develop your code using this interactive example.

\
[https://www.codingrooms.com/block/ide/62ddcb02-2e5c-4f1c-a566-6130684b8bf1](https://www.codingrooms.com/block/ide/62ddcb02-2e5c-4f1c-a566-6130684b8bf1)

\
\
After you complete your code above, paste in your code below to run it through the auto-grader.

Copy and paste your code from the above interactive example and run to see if it passes the autograder tests. Note that this code will only run with the autograder’s input and will not ask the user for input.

\
[https://www.codingrooms.com/block/ide/e4335f01-2679-4bc5-a304-3a34eec94982](https://www.codingrooms.com/block/ide/e4335f01-2679-4bc5-a304-3a34eec94982)

\
## 3.3.3. Summary

* If statements can be followed by an associated **else** part to form a 2-way branch:

```java
if (boolean expression)
{
    Do statement;
}
else
{
    Do other statement;
}
```

* A two way selection (if/else) is written when there are two sets of statements: one to be executed when the Boolean condition is true, and another set for when the Boolean condition is false.
* The body of the “if” statement is executed when the Boolean condition is true, and the body of the “else” is executed when the Boolean condition is false.
* Use 2 test-cases to find errors or validate results to try both branches of an if/else statement.
* The else statement attaches to the closest unmatched if statement in the same block of statements.

## 3.3.4. AP Practice

\
[https://www.codingrooms.com/block/mc/48ac508f-ab8f-408d-9239-2b8f2229a003](https://www.codingrooms.com/block/mc/48ac508f-ab8f-408d-9239-2b8f2229a003)

\
