// Copy in your code from the above interactive version below (include import and public class Main)

