public class DriversLicenseTest
{
   public static void main(String[] args)
   {
     int age = 16;
     if (age >= 16)
     {
         System.out.println("You can get a driver's license in most states!");
     }
     else
     {
         System.out.println("Sorry, you need to be older to get a driver's license.");
     }
   }
}
