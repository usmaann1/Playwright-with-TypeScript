public class ScoreTest
{
   public static void main(String[] args)
   {
       int score = 8;
       if (score <= 9)
       {
         System.out.println("Try for a higher score!");
       }
   }
}
