public class Test2
{
   public static void main(String[] args)
   {
     boolean isHeads = true;
     if (isHeads)
     {
         System.out.println("Let's go to the game");
     }
     else
     {
         System.out.println("Let's watch a movie");
     }
     System.out.println("after conditional");
   }
}
