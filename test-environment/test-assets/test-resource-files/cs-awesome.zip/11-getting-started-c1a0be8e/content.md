 ![](https://www.codingrooms.com/images/courses/csawesome/_images/time90.png ",,NaN")

# 1.1. Getting Started

\
Follow the links below to learn more about the AP CS A course and exam and Java development environments. Please complete the pretest to see where you are with your knowledge of Java before beginning this course and then complete the brief demographic survey. The Java lessons start in 1.2.

Getting Started

* [1.1.1. Preface](course/csawesome-%282022-2023%29-%28juicemind%29-TCj7E9E/b/4b90e579-d597-4030-934c-fc50560c6d1d)
* [1.1.2. About the AP CS A Exam](course/csawesome-%282022-2023%29-%28juicemind%29-TCj7E9E/b/f3f1fbb9-1e88-4034-8b5d-32a42144f71e)
* [1.1.3. Transitioning from AP CSP to AP CS A](course/csawesome-%282022-2023%29-%28juicemind%29-TCj7E9E/b/59a5c1f4-479c-4ea1-a80a-d1590ef0a5a2)
* [1.1.4. Java Development Environments](course/csawesome-%282022-2023%29-%28juicemind%29-TCj7E9E/b/d780f0ac-803f-4a7f-ad15-4e88ad4ae80b)
  * 1.1.4.1. CodingRooms
  * 1.1.4.2. Dr. Java
  * 1.1.4.3. BlueJ
  * 1.1.4.4. jGRASP
  * 1.1.4.5. IntelliJ
  * 1.1.4.6. Netbeans
  * 1.1.4.7. Eclipse
* [1.1.5. Growth Mindset and Pair Programming](course/csawesome-%282022-2023%29-%28juicemind%29-TCj7E9E/b/36f2ca53-57db-4491-8ed6-98d62a91809e)
  * 1.1.5.1. Growth Mindset
  * 1.1.5.2. Pair Programming
* [1.1.6. Pretest for the AP CS A Exam](course/csawesome-%282022-2023%29-%28juicemind%29-TCj7E9E/b/3c8aea41-7843-49d6-86c5-a0af85b0d2c5)
* 1.1.7. Survey
  * 1.1.7.1. Sisters Rise Up
  * 1.1.7.2. Survey

\
\
