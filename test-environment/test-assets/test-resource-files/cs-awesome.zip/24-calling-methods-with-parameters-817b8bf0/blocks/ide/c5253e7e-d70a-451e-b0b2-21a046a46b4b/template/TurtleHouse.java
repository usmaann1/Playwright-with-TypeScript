import java.util.*;
import java.awt.*;

public class TurtleHouse
{
  public static void main(String[] args)
  {
      World world = new World(300,300);



      world.show(true);
  }
}
