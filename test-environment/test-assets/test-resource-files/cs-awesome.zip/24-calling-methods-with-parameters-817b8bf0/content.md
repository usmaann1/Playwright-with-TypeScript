 ![](https://www.codingrooms.com/images/courses/csawesome/_images/time90.png ",,NaN")

# 2.4. Calling Methods With Parameters

\
In the last lessons, we used simple **methods** like forward() and turnRight() to make the turtle draw lines. You may have noticed that forward() and backward() always move the same number of pixels (100 pixels), and turnRight() and turnLeft() always turn at right angles (90 degrees). This is a little limiting. What if we wanted to draw a triangle or the letter A? These require smaller angles to draw diagonal lines and different length lines. Luckily, there are more complex methods in the Turtle class that let you specify the number of pixels to move forward or the number of degrees to turn. These values that you can give to methods to help them do their job are called **arguments** or **parameters**.

\
The parentheses () after method names are there in case you need to give the method **actual parameters** or **arguments** (some data) to do its job. For example, we can give the argument 100 in forward(100) to make the turtle go forward 100 pixels or the argument 30 in turn(30) to make the turtle turn 30 degrees instead of 90 degrees.

\

:::tip 
Note

object.method(arguments); is used to call an object’s method and give it some arguments (actual parameters) to do its job.

:::

\
\
Although some people use the words parameters and arguments interchangeably, there is a subtle difference. When you create your own method, the variables you define for it are called **formal parameters**. When you call the method to do its job, you give or pass in **arguments** or **actual parameters** to it that are then saved in the parameter variables. So, in the definition of the forward method, it has a parameter variable called pixels, and in the call to forward(100), the argument is the value 100 which will get saved in the parameter variable pixels. You will learn to write your own methods in Unit 5. In this unit, you will learn to call methods that are already written for you.

```java
// Method call
yertle.forward(100); // argument is 100

// Method definition written for you
public void forward(int pixels) // parameter pixels
...
```

\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") **Check your understanding**

\
[https://www.codingrooms.com/block/dragndrop/44c7bf8e-070e-43ac-b2bb-90bec424414b](https://www.codingrooms.com/block/dragndrop/44c7bf8e-070e-43ac-b2bb-90bec424414b)

\
 ![](https://www.codingrooms.com/images/courses/csawesome/_images/turtleTurnForwardRightForward.png ",,NaN")

\
[https://www.codingrooms.com/block/parsons/ccc7facf-a3da-45dc-8747-5538729bfb05](https://www.codingrooms.com/block/parsons/ccc7facf-a3da-45dc-8747-5538729bfb05)

\
\
Here is the Turtle class diagram again that shows some of the variables and methods inherited from the SimpleTurtle class in the class Turtle that are written for you.

 ![Turtle class diagram](https://www.codingrooms.com/images/courses/csawesome/_images/turtleUMLClassDiagram.png ",,NaN")

Figure 1: Turtle Class Diagram

\
Try some of the methods above in the turtle code below. You can see all the methods that are inherited in Turtle in this [javadoc (documentation) file](https://www2.cs.uic.edu/\~i101/doc/SimpleTurtle.html).

\
Methods are said to be **overloaded** when there are multiple methods with the same name but a different **method signature**, where it requires a different number or type of parameters. For example, we have two different forward methods, forward() with no parameters and forward(100) which has a parameter that tells it how much to move forward. If there is more than one parameter, then the values given to the method need to correspond to the order and types in the method signature.

\
 ![coding exercise](https://www.codingrooms.com/images/courses/csawesome/_images/codingExercise.png "left-icon,,NaN") **Coding Exercise**

1. Can you make yertle draw a square and change the pen color for each side of the square? Try something like: yertle.setColor(Color.red); This uses the [Color](https://docs.oracle.com/javase/7/docs/api/java/awt/Color.html) class in Java which has some colors predefined like red, yellow, blue, magenta, cyan. You can also use more specific methods like setPenColor, setBodyColor, and setShellColor.
2. Can you draw a triangle? The turnRight() method always does 90 degree turns, but you’ll need external angles of 120 degree for an equilateral triangle. Use the turn method which has a parameter for the angle of the turn in degrees. For example, turn(90) is the same as turnRight(). Try drawing a triangle with different colors.

\
[https://www.codingrooms.com/block/ide/4a059538-b96c-4bac-99c4-9bfd8f33e914](https://www.codingrooms.com/block/ide/4a059538-b96c-4bac-99c4-9bfd8f33e914)

\
\
 ![coding exercise](https://www.codingrooms.com/images/courses/csawesome/_images/codingExercise.png "left-icon,,NaN") **Coding Exercise**

\
Try the following mixed up code to draw a simple house made of a square and a triangle roof.

 ![simple house](https://www.codingrooms.com/images/courses/csawesome/_images/house.png ",,NaN")

\
[https://www.codingrooms.com/block/parsons/42680c21-8747-4cbd-8201-6d6b3dd50d70](https://www.codingrooms.com/block/parsons/42680c21-8747-4cbd-8201-6d6b3dd50d70)

\
## 2.4.1. Tracing Methods

\
You will not write your own methods until Unit 5, but you should be able to trace and interpret method calls like below.

\
Here is another version of the Old MacDonald Song with a more powerful abstraction. The method verse has 2 parameters for the animal and the noise it makes, so that it can be used for any animal. Use the Code Lens button or this [Java visualizer](http://www.pythontutor.com/java.html#code%3Dpublic%20class%20Song%20%0A%7B%0A%20%20%0A%20%20%20%20public%20void%20verse%28String%20animal,%20String%20noise%29%20%0A%20%20%20%20%7B%0A%20%20%20%20%20%20%20%20System.out.println%28%22Old%20MacDonald%20had%20a%20farm%22%29%3B%0A%20%20%20%20%20%20%20%20chorus%28%29%3B%0A%20%20%20%20%20%20%20%20System.out.println%28%22And%20on%20that%20farm%20he%20had%20a%20%22%20%2B%20animal%29%3B%0A%20%20%20%20%20%20%20%20chorus%28%29%3B%0A%20%20%20%20%20%20%20%20System.out.println%28%22With%20a%20%22%20%2B%20noise%20%2B%20%22%20%22%20%2B%20noise%20%2B%20%22%20here,%22%29%3B%0A%20%20%20%20%20%20%20%20System.out.println%28%22And%20a%20%22%20%2B%20noise%20%2B%20%22%20%22%20%2B%20noise%20%2B%20%22%20there,%22%29%3B%0A%20%20%20%20%20%20%20%20System.out.println%28%22Old%20MacDonald%20had%20a%20farm%22%29%3B%0A%20%20%20%20%20%20%20%20chorus%28%29%3B%0A%20%20%20%20%7D%0A%20%20%20%20public%20void%20chorus%28%29%0A%20%20%20%20%7B%0A%20%20%20%20%20%20%20%20System.out.println%28%22E-I-E-I-O%22%29%3B%0A%20%20%20%20%7D%0A%20%20%20%20%0A%20%20%20%20public%20static%20void%20main%28String%5B%5D%20args%29%20%0A%20%20%20%20%7B%0A%20%20%20%20%20%20%20Song%20s%20%3D%20new%20Song%28%29%3B%0A%20%20%20%20%20%20%20s.verse%28%22cow%22,%20%22moo%22%29%3B%0A%20%20%20%20%20%20%20s.verse%28%22duck%22,%22quack%22%29%3B%0A%20%20%20%20%7D%0A%7D&cumulative%3Dfalse&curInstr%3D1&heapPrimitives%3Dnevernest&mode%3Ddisplay&origin%3Dopt-frontend.js&py%3Djava&rawInputLstJSON%3D%5B%5D&textReferences%3Dfalse) to step through the code.

Add another verse in main that calls the method verse with a different animal and noise.

\
[https://www.codingrooms.com/block/ide/7f2f347b-ded9-4f6e-a1ad-c70c23d12131](https://www.codingrooms.com/block/ide/7f2f347b-ded9-4f6e-a1ad-c70c23d12131)

\
\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") **Check your understanding**

\
[https://www.codingrooms.com/block/mc/d742d6a6-e6a5-455f-a7ab-bacd1f357321](https://www.codingrooms.com/block/mc/d742d6a6-e6a5-455f-a7ab-bacd1f357321)

\
\
Try this [visualization](http://www.pythontutor.com/visualize.html#code%3D%20%20public%20class%20MethodTrace%20%0A%20%20%20%20%20%20%7B%0A%20%20%20%20%20%20%20%20public%20void%20square%28int%20x%29%0A%20%20%20%20%20%20%20%20%7B%0A%20%20%20%20%20%20%20%20%20%20%20%20System.out.print%28x\*x%29%3B%0A%20%20%20%20%20%20%20%20%7D%0A%20%20%20%20%20%20%20%20public%20void%20divide%28int%20x,%20int%20y%29%0A%20%20%20%20%20%20%20%20%7B%0A%20%20%20%20%20%20%20%20%20%20%20%20System.out.println%28x/y%29%3B%0A%20%20%20%20%20%20%20%20%7D%0A%20%20%20%20%20%20%20%20public%20static%20void%20main%28String%5B%5D%20args%29%20%7B%0A%20%20%20%20%20%20%20%20%20%20%20%20MethodTrace%20traceObj%20%3D%20new%20MethodTrace%28%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20traceObj.square%285%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20System.out.print%28%22%20and%20%22%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20traceObj.divide%284,2%29%3B%0A%20%20%20%20%20%20%20%20%7D%0A%20%20%20%20%20%20%20%7D&cumulative%3Dfalse&curInstr%3D18&heapPrimitives%3Dnevernest&mode%3Ddisplay&origin%3Dopt-frontend.js&py%3Djava&rawInputLstJSON%3D%5B%5D&textReferences%3Dfalse) to see this code in action.

## 2.4.2.  ![groupwork](https://www.codingrooms.com/images/courses/csawesome/_images/groupwork.png "left-icon,,NaN") Programming Challenge : Turtle House

 ![simple house](https://www.codingrooms.com/images/courses/csawesome/_images/houseWithWindows.png ",,NaN")

\
This creative challenge is fun to do collaboratively in pairs. Design a house and have the turtle draw it with different colors below. Can you add windows and a door? Come up with your own house design as a team.

\
To draw a window, you will need to do penUp() to walk the turtle into position, for example:

```java
builder.penUp();
builder.moveTo(120,200);
builder.penDown();
```

\
It may help to act out the code pretending you are the turtle. Remember that the angles you turn depend on which direction you are facing, and the turtle begins facing up.

Draw a Turtle House! Make sure you use forward, turn, penUp, penDown, moveTo methods as well as different colors. Have fun!

\
[https://www.codingrooms.com/block/ide/c5253e7e-d70a-451e-b0b2-21a046a46b4b](https://www.codingrooms.com/block/ide/c5253e7e-d70a-451e-b0b2-21a046a46b4b)

\
## 2.4.3. Summary

* **Methods** define the behaviors or functions for objects.
* To use an object’s method, you must use the object name and the dot (.) operator followed by the method name, for example **object.method();**
* Some methods take parameters/arguments that are placed inside the parentheses **object.method(arguments)**.
* Values provided in the parameter list need to correspond to the order and type in the method signature.

## 2.4.4. AP Practice

\
[https://www.codingrooms.com/block/mc/0c0f7bbb-c3d7-451f-911b-228b0da67ec7](https://www.codingrooms.com/block/mc/0c0f7bbb-c3d7-451f-911b-228b0da67ec7)

\
\
[https://www.codingrooms.com/block/mc/1b32a664-0494-4cd4-980c-4bd9821529f3](https://www.codingrooms.com/block/mc/1b32a664-0494-4cd4-980c-4bd9821529f3)

\
