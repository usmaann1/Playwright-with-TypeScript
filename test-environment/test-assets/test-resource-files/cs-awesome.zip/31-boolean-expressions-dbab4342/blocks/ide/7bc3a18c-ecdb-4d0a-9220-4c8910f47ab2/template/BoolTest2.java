public class BoolTest2
{
   public static void main(String[] args)
   {
     int age = 15;
     int year = 14;
     // Will these print true or false?
     System.out.println( age < year );
     System.out.println( age > year );
     System.out.println( age <= year+1 );
     System.out.println( age-1 >= year );
   }
}
