public class BoolTest1
{
   public static void main(String[] args)
   {
     int age = 15;
     int year = 14;
     // Will this print true or false?
     System.out.println( age == year );
     year = 15;
     // Will this print true or false?
     System.out.println( age == year );
     // Will this print true or false?
     System.out.println( age != year );
   }
}
