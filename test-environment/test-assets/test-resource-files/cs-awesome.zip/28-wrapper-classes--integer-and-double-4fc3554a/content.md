 ![](https://www.codingrooms.com/images/courses/csawesome/_images/time45.png ",,NaN")

# 2.8. Wrapper Classes - Integer and Double

\
For every primitive type in Java, there is a built-in object type called a wrapper class. The wrapper class for int is called Integer, and for double it is called Double. Sometimes you may need to create a wrapped object for a primitive type so that you can give it to a method that is expecting an object. To wrap a value, call the constructor for the wrapper class in earlier versions of Java. In Java 9 on, this is **deprecated** which means it’s not the best way to do this anymore, and you should instead just set it equal to a value. The AP CS A Exam covers Java 7 which does allow using the constructor.

```java
// in older versions of Java (and on the AP exam)
Integer i = new Integer(2); // create an object with 2 in it
Double d = new Double(3.5); // create an object with 3.5 in it

// in newer versions of Java (9+)
Integer i = 2;
Double d = 3.5;
```

\
These wrapper classes (defined in the java.lang package) are also useful because they have some special values (like the minimum and maximum values for the type) and methods that you can use. Try the following code to see the minimum and maximum values possible for the type int.

What’s the minimum and maximum numbers for an int? What happens if you go beyond these limits with - 1 or + 1?

\
[https://www.codingrooms.com/block/ide/df4ab333-c619-4a66-ac59-07daadc38e8c](https://www.codingrooms.com/block/ide/df4ab333-c619-4a66-ac59-07daadc38e8c)

\
\
The int type in Java can be used to represent any whole number from -2147483648 to 2147483647. Why those numbers? Integers in Java are represented in 2’s complement binary and each integer gets 32 bits of space. In 32 bits of space with one bit used to represent the sign you can represent that many values. Why is there one more negative number than positive number? It is because 0 is considered a positive number.

\
What do the last two lines print out? Did this surprise you? Java will actually return the maximum integer value if you try to subtract one from the minimum value. This is called **underflow**. And, Java will return the minimum integer value if you try to add one to the maximum. This is called **overflow**. It is similar to how odometers work – in a really old car that reaches the maximum miles possible on the odometer, the odometer rolls over back to 0, the minimum value. In Java, any int value that surpasses 32 bits gets rolled over, so that the Integer.MAX_VALUE 2147483647 incremented (+1) returns -2147483648 which is the Integer.MIN_VALUE.

\
When would you ever use Integer.MIN_VALUE or Integer.MAX_VALUE? They are handy if you want to initialize a variable to the smallest possible value and then search a sequence of values for a larger value.

\
**Autoboxing** is the automatic conversion that the Java compiler makes between primitive types and their corresponding object wrapper classes. This includes converting an int to an Integer and a double to a Double. The Java compiler applies autoboxing when a primitive value is passed as a parameter to a method that expects an object of the corresponding wrapper class or assigned to a variable of the corresponding wrapper class. Here’s an example of autoboxing.

```java
Integer i = 2;
Double d = 3.5;
```

\
**Unboxing** is the automatic conversion that the Java compiler makes from the wrapper class to the primitive type. This includes converting an Integer to an int and a Double to a double. The Java compiler applies unboxing when a wrapper class object is passed as a parameter to a method that expects a value of the corresponding primitive type or assigned to a variable of the corresponding primitive type. Here’s an example of unboxing:

```java
Integer i = 2;  // autoboxing - wrap 2
int number = i; // unboxing - back to primitive type
```

\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") **Check your understanding**

\
[https://www.codingrooms.com/block/dragndrop/a35201ac-8bf6-4418-8e25-bd3c8e16d7d6](https://www.codingrooms.com/block/dragndrop/a35201ac-8bf6-4418-8e25-bd3c8e16d7d6)

\
\
Here are some more useful methods in the Integer and Double classes:

Run the code below to see useful methods in the Integer and Double wrapper classes.

\
[https://www.codingrooms.com/block/ide/bad117aa-9109-457e-9c47-a4f2f529bfaa](https://www.codingrooms.com/block/ide/bad117aa-9109-457e-9c47-a4f2f529bfaa)

\
## 2.8.1.  ![groupwork](https://www.codingrooms.com/images/courses/csawesome/_images/groupwork.png "left-icon,,NaN") Programming Challenge : Debugging

\
Can you find and fix all the bugs in the following code to use the correct Integer and Double methods and variables?

Find and fix the bugs below to use the correct Integer and Double methods and variables.

\
[https://www.codingrooms.com/block/ide/5b172cf8-cd21-437f-a29d-03fb0fc9b351](https://www.codingrooms.com/block/ide/5b172cf8-cd21-437f-a29d-03fb0fc9b351)

\
## 2.8.2. Summary

* The Integer class and Double class are **wrapper classes** that create objects from primitive types.
* The following Integer methods and constructors, including what they do and when they are used, are part of the Java Quick Reference.
  * Integer(value): Constructs a new Integer object that represents the specified int value.
  * Integer.MIN_VALUE : The minimum value represented by an int or Integer.
  * Integer.MAX_VALUE : The maximum value represented by an int or Integer.
  * int intValue() : Returns the value of this Integer as an int.
* The following Double methods and constructors, including what they do and when they are used, are part of the Java Quick Reference Guide given during the exam:
  * Double(double value) : Constructs a new Double object that represents the specified double value.
  * double doubleValue() : Returns the value of this Double as a double.
* **Autoboxing** is the automatic conversion that the Java compiler makes between primitive types and their corresponding object wrapper classes. This includes converting an int to an Integer and a double to a Double.
* The Java compiler applies autoboxing when a primitive value is:
  * Passed as a parameter to a method that expects an object of the corresponding wrapper class.
  * Assigned to a variable of the corresponding wrapper class.
* **Unboxing** is the automatic conversion that the Java compiler makes from the wrapper class to the primitive type. This includes converting an Integer to an int and a Double to a double.
* The Java compiler applies unboxing when a wrapper class object is:
  * Passed as a parameter to a method that expects a value of the corresponding primitive type.
  * Assigned to a variable of the corresponding primitive type.