public class Test1
{
   public static void main(String[] args)
   {
     System.out.println(Integer.MIN_VALUE);
     System.out.println(Integer.MAX_VALUE);
     System.out.println(Integer.MIN_VALUE - 1);
     System.out.println(Integer.MAX_VALUE + 1);
   }
}
