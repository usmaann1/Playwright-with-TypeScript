public class Debug
{
   public static void main(String[] args)
   {
     integer i = 2.3;
     Double d = 5;
     System.out.println( i.intValue );
     System.out.println( doubleValue() );
     // Print out the min and max values possible for integers
     System.out.println(Integer.min_value);
     System.out.println( int.MAX_VALUE() );
   }
}
