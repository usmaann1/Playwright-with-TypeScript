# 2.12. Toggle Mixed Up or Write Code Practice

> For each of the problems below, if you need help, you can pull down the toggle menu to choose the associated mixed up code problem to help you get started.

\
For the mixed up code problems, drag the blocks into the correct order. Click the *Check Me* button to check each solution. You will be told if your solution is too short, has a block in the wrong order, or you are using the wrong block. Some of the problems may have an extra block that isn’t needed in the correct solution. After 3 tries, you can ask for help and some of the blocks will be combined. You can solve these on your phone or other mobile device!

\
[https://www.codingrooms.com/block/tabs/5f339929-b032-4dd9-a523-fd039d6fbc3a](https://www.codingrooms.com/block/tabs/5f339929-b032-4dd9-a523-fd039d6fbc3a)

\
\
[https://www.codingrooms.com/block/tabs/b7568ea2-5dd7-4cc3-a701-9ef99b59c646](https://www.codingrooms.com/block/tabs/b7568ea2-5dd7-4cc3-a701-9ef99b59c646)

\
\
[https://www.codingrooms.com/block/tabs/9995c8af-4233-4e6c-8a26-a04a4e0afd47](https://www.codingrooms.com/block/tabs/9995c8af-4233-4e6c-8a26-a04a4e0afd47)

\
\
[https://www.codingrooms.com/block/tabs/f813cec0-3716-4b2a-a820-4cabffa322b4](https://www.codingrooms.com/block/tabs/f813cec0-3716-4b2a-a820-4cabffa322b4)

\
\
[https://www.codingrooms.com/block/tabs/4adae720-b56d-4d3e-9097-f4426661f1a8](https://www.codingrooms.com/block/tabs/4adae720-b56d-4d3e-9097-f4426661f1a8)

\
\
[https://www.codingrooms.com/block/tabs/833e65cc-b957-4be8-adf3-df73c7ccb795](https://www.codingrooms.com/block/tabs/833e65cc-b957-4be8-adf3-df73c7ccb795)

\
