public class Test1
{
    public static void main(String[] args)
    {
       String message = "I hope this works";
       // Add your code here


    }
 }
 