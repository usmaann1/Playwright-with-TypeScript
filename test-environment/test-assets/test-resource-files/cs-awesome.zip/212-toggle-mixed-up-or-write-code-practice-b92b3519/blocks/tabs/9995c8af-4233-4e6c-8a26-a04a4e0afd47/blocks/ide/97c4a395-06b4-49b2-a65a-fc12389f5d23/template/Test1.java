public class Test1
{
    public static void main(String[] args)
    {
         String first = "Gerald";
         String middle = "Foster";
         String last= "Jones";

         // Add your code here


    }
 }
 