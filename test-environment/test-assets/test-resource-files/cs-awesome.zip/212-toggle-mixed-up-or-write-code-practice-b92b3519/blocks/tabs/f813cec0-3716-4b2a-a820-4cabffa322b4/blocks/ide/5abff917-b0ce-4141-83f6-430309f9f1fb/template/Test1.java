public class Test1
{
    public static void main(String[] args)
    {
         String message = "Don't Pokemon and drive!";

         // Add your code here


    }
 }
 