 ![](https://www.codingrooms.com/images/courses/csawesome/_images/time45.png ",,NaN")

# 2.3. Calling Methods Without Parameters

\
**Methods** are a set of instructions that define behaviors for all objects of a class. For example, in the `Turtle` class, methods like `forward()` and `turnRight()` give `Turtle` objects the ability to move forward and turn 90 degrees right.

\
To use an object’s method, you must use the object name and the dot (.) operator followed by the method name, for example, `yertle.forward();` calls `yertle`’s `forward` method to move a turtle object forward 100 pixels. These are called **object methods** or **non-static methods**. An object method *must* be called on an object of the class that the method is defined in. Object methods work with the **attributes** of the object, such as the direction the turtle is heading or its position.

\
Every method call is followed by parentheses. The parentheses `()` after method names are there in case you need to give the method parameters (data) to do its job, which we will see in the next lesson. You must always include the parentheses after the method name.

\

:::tip 
Note

object.method(); is used to call an object’s method.

:::

\
\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") **Check Your Understanding: Mixed-up Code**

\
[https://www.codingrooms.com/block/parsons/e86c83bf-a22b-41da-bf85-b47151021868](https://www.codingrooms.com/block/parsons/e86c83bf-a22b-41da-bf85-b47151021868)

\
\
 ![coding exercise](https://www.codingrooms.com/images/courses/csawesome/_images/codingExercise.png "left-icon,,NaN") **Coding Exercise:**

\
After you put the mixed up code in order above, type in the same code below to make the turtle draw a 7.

\
[https://www.codingrooms.com/block/ide/d369eef1-29d5-4f9c-91b9-15ebb235281d](https://www.codingrooms.com/block/ide/d369eef1-29d5-4f9c-91b9-15ebb235281d)

\
\
 ![coding exercise](https://www.codingrooms.com/images/courses/csawesome/_images/codingExercise.png "left-icon,,NaN") **Coding Exercise:**

Can you make yertle draw the digital number 8, as 2 squares on top of each other?

\
[https://www.codingrooms.com/block/ide/8dcea47f-65b7-45d8-a452-a41b5478872a](https://www.codingrooms.com/block/ide/8dcea47f-65b7-45d8-a452-a41b5478872a)

\
## 2.3.1. Procedural Abstraction

\
**Procedural abstraction** allows a programmer to use a method and not worry about the details of how it exactly works. For example, we know that if we hit the brakes, the car will stop, and we can still use the brakes even if we don’t really know how they work.

\
You will learn to write your own methods in Unit 5. In this unit, you should be able to use methods already written for you and figure out what they do. When we use methods for a class in a library, we can look up the **method signature** (or **method header**), which is the method name followed by a parameter list, in its documentation. For example, here is a `Student` class with a method signature `public void print()` which has an empty parameter list with no parameters. Methods are defined after the instance variables (attributes) and constructors in a class.

 ![A Student class showing instance variables, constructors, and methods](https://www.codingrooms.com/images/courses/csawesome/_images/StudentClass.png ",,NaN")

Figure 1: A Student class showing instance variables, constructors, and methods

\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") Check Your Understanding

\
[https://www.codingrooms.com/block/clickable/3e004a80-fc72-482e-814b-356b021f5f07](https://www.codingrooms.com/block/clickable/3e004a80-fc72-482e-814b-356b021f5f07)

\
\
The Java [visualization](http://www.pythontutor.com/java.html#code%3Dpublic%20class%20Song%20%7B%0A%20%20%0A%20%20%20%20public%20void%20print%28%29%20%7B%0A%20%20%20%20%20%20%20%20System.out.println%28%22Old%20MacDonald%20had%20a%20farm%22%29%3B%0A%20%20%20%20%20%20%20%20chorus%28%29%3B%0A%20%20%20%20%20%20%20%20System.out.print%28%22And%20on%20that%20farm%20he%20had%20a%20%22%29%3B%0A%20%20%20%20%20%20%20%20animal%28%29%3B%0A%20%20%20%20%20%20%20%20chorus%28%29%3B%0A%20%20%20%20%7D%0A%20%20%20%20public%20void%20chorus%28%29%0A%20%20%20%20%7B%0A%20%20%20%20%20%20%20%20System.out.println%28%22E-I-E-I-O%22%29%3B%0A%20%20%20%20%7D%0A%20%20%20%20%0A%20%20%20%20public%20void%20animal%28%29%20%7B%0A%20%20%20%20%20%20%20System.out.println%28%22duck%22%29%3B%0A%20%20%20%20%7D%0A%20%20%20%20public%20static%20void%20main%28String%5B%5D%20args%29%20%7B%0A%20%20%20%20%20%20%20Song%20s%20%3D%20new%20Song%28%29%3B%0A%20%20%20%20%20%20%20s.print%28%29%3B%0A%20%20%20%20%7D%0A%7D&cumulative%3Dfalse&curInstr%3D1&heapPrimitives%3Dnevernest&mode%3Ddisplay&origin%3Dopt-frontend.js&py%3Djava&rawInputLstJSON%3D%5B%5D&textReferences%3Dfalse) below shows how a song can be divided up into methods. Click on the next button below the code to step through the code. Execution in Java always begins in the `main` method in the current class. Then, the flow of control skips from method to method as they are called. The Song’s print method calls the chorus() and animal() methods to help it print out the whole song.

\
When you call the chorus() method, it skips to the chorus code, executes and prints out the chorus, and then returns back to the method that called it.

\
[https://www.codingrooms.com/block/embed/140d9677-6492-4700-bf71-3f3df4cdb5dc](https://www.codingrooms.com/block/embed/140d9677-6492-4700-bf71-3f3df4cdb5dc)

\
\
Methods inside the same class can call each other using just `methodName()`, but to call non-static methods in another class or from a main method, you must first create an object of that class and then call its methods using `object.methodName()`.

 ![Calling Methods](https://www.codingrooms.com/images/courses/csawesome/_images/calling-methods.png ",,NaN")

Figure 2: Calling non-static methods from main() or from other methods inside the same class.

\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") **Check your understanding**

\
[https://www.codingrooms.com/block/mc/cfd5cd84-ab3a-4f39-ab10-d75f58d174ff](https://www.codingrooms.com/block/mc/cfd5cd84-ab3a-4f39-ab10-d75f58d174ff)

\
\
Try this [visualization](http://www.pythontutor.com/visualize.html#code%3Dpublic%20class%20Song%20%7B%0A%20%20%0A%20%20%20%20%20%20%20%20public%20void%20print%28%29%20%7B%0A%20%20%20%20%20%20%20%20%20%20%20%20System.out.print%28%22I%20like%20to%20%22%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20eat%28%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20eat%28%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20eat%28%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20fruit%28%29%3B%0A%20%20%20%20%20%20%20%20%7D%0A%20%20%20%20%20%20%20%20public%20void%20fruit%28%29%0A%20%20%20%20%20%20%20%20%7B%0A%20%20%20%20%20%20%20%20%20%20%20%20System.out.println%28%22apples%20and%20bananas!%22%29%3B%0A%20%20%20%20%20%20%20%20%7D%0A%20%20%20%20%20%20%20%20%0A%20%20%20%20%20%20%20%20public%20void%20eat%28%29%20%7B%0A%20%20%20%20%20%20%20%20%20%20%20System.out.print%28%22eat%20%22%29%3B%0A%20%20%20%20%20%20%20%20%7D%0A%20%20%20%20%20%20%20%20public%20static%20void%20main%28String%5B%5D%20args%29%20%7B%0A%20%20%20%20%20%20%20%20%20%20%20Song%20s%20%3D%20new%20Song%28%29%3B%0A%20%20%20%20%20%20%20%20%20%20%20s.print%28%29%3B%0A%20%20%20%20%20%20%20%20%7D%0A%20%20%20%20%7D&cumulative%3Dfalse&curInstr%3D1&heapPrimitives%3Dnevernest&mode%3Ddisplay&origin%3Dopt-frontend.js&py%3Djava&rawInputLstJSON%3D%5B%5D&textReferences%3Dfalse) to see this code in action.

\

:::tip 
Note

method(); is used to call a method within the same class, but object.method(); is necessary if you are calling the method from the main method or from a different class.

:::

\
\
Before you call a method from `main` or from outside of the current class, you must make sure that you have created and initialized an object. Remember that if you just declare an object reference without setting it to refer to a new object the value will be `null` meaning that it doesn’t reference an object. If you call a method on a variable whose value is `null`, you will get a **NullPointerException** error, where a **pointer** is another name for a reference.

## 2.3.2.  ![groupwork](https://www.codingrooms.com/images/courses/csawesome/_images/groupwork.png "left-icon,,NaN") Programming Challenge : Draw a Letter

\
Working in pairs, use the area below to use a turtle to draw a simple block-style letter or number that uses just straight lines (no curves or diagonals). It could be one of your initials or a number from today’s date.

\
It may help to act out the code pretending you are the turtle. Remember that which way you turn depends on which direction you are facing, and the turtle begins facing north (towards the top of the page).

\
Here are some simple turtle methods that you can use:

* `forward()`
* `turnLeft()`
* `turnRight()`
* `backward()`
* `penUp()`
* `penDown()`

\
You may notice that it is challenging to have your turtle draw with these simple methods. In the next lesson, we will use more complex `Turtle` methods where you can indicate how many steps to take or what angle to turn that will make drawing a lot easier!

Create a drawing of a simple letter or number that uses just straight lines (no curves or diagonals). It could be an initial in your name or a number from today’s date.

\
[https://www.codingrooms.com/block/ide/d4360fc1-8a61-46f0-a3d0-d1266d1aaa4d](https://www.codingrooms.com/block/ide/d4360fc1-8a61-46f0-a3d0-d1266d1aaa4d)

\
## 2.3.3. Summary

* **Methods** are a set of instructions that define the behaviors for all objects of the class.
* Use **dot notation** to execute an object’s method. This is the object’s name followed by the dot (.) operator followed by the method name and parentheses: **object.method();**
* A **method signature** is the method name followed by the parameter list which gives the type and name for each parameter. Note that methods do not have to take any parameters, but you still need the parentheses after the method name.
* **Procedural abstraction** allows a programmer to use a method by knowing in general what it does without knowing what lines of code execute. This is how we can drive a car without knowing how the brakes work.
* A **method** or **constructor** call interrupts the sequential execution of statements, causing the program to first execute the statements in the method or constructor before continuing. Once the last statement in the method or constructor has executed or a return statement is executed, the flow of control is returned to the point immediately following the method or constructor call.
* A **NullPointerException** will happen if you try to call an object method on an object variable whose value is `null`. This usually means that you forgot to create the object using the `new` operator followed by the class name and parentheses.
* An **object method** or **non-static method** is one that must be called on an object of a class. It usually works with the object’s attributes.
* A **static method** or **class method** method is one that doesn’t need to be called on an object of a class.

## 2.3.4. AP Practice

\
[https://www.codingrooms.com/block/mc/489c42f6-b68b-4d8e-8739-eb5854eec8dc](https://www.codingrooms.com/block/mc/489c42f6-b68b-4d8e-8739-eb5854eec8dc)

\
\
[https://www.codingrooms.com/block/mc/9d8c65bd-b596-4357-86c7-77e87b0e794a](https://www.codingrooms.com/block/mc/9d8c65bd-b596-4357-86c7-77e87b0e794a)

\
