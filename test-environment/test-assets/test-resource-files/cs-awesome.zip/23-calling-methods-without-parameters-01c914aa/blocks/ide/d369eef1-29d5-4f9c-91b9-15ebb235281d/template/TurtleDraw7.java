import java.util.*;
import java.awt.*;

public class TurtleDraw7
{
  public static void main(String[] args)
  {
      World habitat = new World(300,300);
      Turtle yertle = new Turtle(habitat);
      // Make yertle draw a 7 using the code above



      habitat.show(true);
  }
}
