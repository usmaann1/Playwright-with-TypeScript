import java.util.*;
import java.awt.*;

public class TurtleLetter
{
  public static void main(String[] args)
  {
      World habitat = new World(300,300);



      habitat.show(true);
  }
}
