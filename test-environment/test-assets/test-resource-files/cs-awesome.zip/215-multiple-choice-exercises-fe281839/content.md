# 2.15. Multiple Choice Exercises

\
These questions are mostly about Strings, but more questions on using other objects will be added in the future.

## 2.15.1. Easier Multiple Choice Questions

\
These problems are mostly easier than what you will see on the AP CS A exam.

\
[https://www.codingrooms.com/block/mc/da850724-d9bc-4494-bff9-8192685e2614](https://www.codingrooms.com/block/mc/da850724-d9bc-4494-bff9-8192685e2614)

\
\
[https://www.codingrooms.com/block/mc/ca2bd35d-d14d-412f-8e27-14b7efa8daa7](https://www.codingrooms.com/block/mc/ca2bd35d-d14d-412f-8e27-14b7efa8daa7)

\
\
[https://www.codingrooms.com/block/mc/7bcad2cf-c91f-4175-afec-41de70aea3f7](https://www.codingrooms.com/block/mc/7bcad2cf-c91f-4175-afec-41de70aea3f7)

\
\
[https://www.codingrooms.com/block/mc/88eae7b2-cb32-4f1b-94b6-4d53f11dd3aa](https://www.codingrooms.com/block/mc/88eae7b2-cb32-4f1b-94b6-4d53f11dd3aa)

\
\
[https://www.codingrooms.com/block/mc/57eaae6d-09b9-43a7-9031-04457f05d437](https://www.codingrooms.com/block/mc/57eaae6d-09b9-43a7-9031-04457f05d437)

\
\
[https://www.codingrooms.com/block/mc/d6e8a4fe-0c80-4413-8b3c-c523c799f838](https://www.codingrooms.com/block/mc/d6e8a4fe-0c80-4413-8b3c-c523c799f838)

\
## 2.15.2. Medium Multiple Choice Questions

\
These problems are similar to those that you will see on the AP CS A exam.

\
[https://www.codingrooms.com/block/mc/0e6d1017-6dba-43da-86dc-88bf60445a00](https://www.codingrooms.com/block/mc/0e6d1017-6dba-43da-86dc-88bf60445a00)

\
\
[https://www.codingrooms.com/block/mc/eddd2990-ee6f-4bfa-88fd-ad33e931720c](https://www.codingrooms.com/block/mc/eddd2990-ee6f-4bfa-88fd-ad33e931720c)

\
\
[https://www.codingrooms.com/block/mc/daf9649b-593d-4095-961a-74e05d85b933](https://www.codingrooms.com/block/mc/daf9649b-593d-4095-961a-74e05d85b933)

\
\
[https://www.codingrooms.com/block/mc/d67c8c5e-80d4-4ad8-a778-3b8015412797](https://www.codingrooms.com/block/mc/d67c8c5e-80d4-4ad8-a778-3b8015412797)

\
\
[https://www.codingrooms.com/block/mc/f6e58f98-faaf-4619-b7cc-e540028043ad](https://www.codingrooms.com/block/mc/f6e58f98-faaf-4619-b7cc-e540028043ad)

\
\
[https://www.codingrooms.com/block/mc/e73e7db3-4524-4676-8e27-b7085a5acc6d](https://www.codingrooms.com/block/mc/e73e7db3-4524-4676-8e27-b7085a5acc6d)

\
\
[https://www.codingrooms.com/block/mc/bb7aedaf-4e04-446b-91ad-ff2c1afa8393](https://www.codingrooms.com/block/mc/bb7aedaf-4e04-446b-91ad-ff2c1afa8393)

\
\
[https://www.codingrooms.com/block/mc/75ef73da-1c8d-44d9-8781-9fc31030b37f](https://www.codingrooms.com/block/mc/75ef73da-1c8d-44d9-8781-9fc31030b37f)

\
\
[https://www.codingrooms.com/block/mc/b86f5c4f-534d-4540-85b1-79de8750dc58](https://www.codingrooms.com/block/mc/b86f5c4f-534d-4540-85b1-79de8750dc58)

\
\
[https://www.codingrooms.com/block/mc/174ea3fe-2c8f-4230-8496-e6cbe0baf5e5](https://www.codingrooms.com/block/mc/174ea3fe-2c8f-4230-8496-e6cbe0baf5e5)

\
## 2.15.3. Hard Multiple Choice Questions

\
These problems are harder than most of those that you will usually see on the AP CS A exam.

\
[https://www.codingrooms.com/block/mc/8962f35a-4368-4b42-8d0f-6a8c3f3b7477](https://www.codingrooms.com/block/mc/8962f35a-4368-4b42-8d0f-6a8c3f3b7477)

\
\
[https://www.codingrooms.com/block/mc/8493e3be-05eb-4beb-9044-c2b308111a8c](https://www.codingrooms.com/block/mc/8493e3be-05eb-4beb-9044-c2b308111a8c)

\
\
[https://www.codingrooms.com/block/mc/c6947b75-c6f1-4b4b-b526-9f6d2df914f9](https://www.codingrooms.com/block/mc/c6947b75-c6f1-4b4b-b526-9f6d2df914f9)

\
\
[https://www.codingrooms.com/block/mc/75d0934b-a243-4618-9265-a766e9d397ad](https://www.codingrooms.com/block/mc/75d0934b-a243-4618-9265-a766e9d397ad)

\
\
[https://www.codingrooms.com/block/mc/9713806d-f7b4-4b2e-a86f-e62ca859f350](https://www.codingrooms.com/block/mc/9713806d-f7b4-4b2e-a86f-e62ca859f350)

\
\
The Mark Complete button and green check mark are intentionally not included for this page because there may be many quiz-bank exercises on this page.