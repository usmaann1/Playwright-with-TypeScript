public class MathChallenge
{
   public static void main(String[] args)
   {
       // 1. Use Math.random() to generate 3 integers from 0-40 (not including 40) and print them out.


       // 2. Calculate the number of combinations to choose 3 numbers between 0-40 (not including 40) using Math.pow() and print it out.
       // For example, Math.pow(10,2) is 10^2 and the number of permutations to choose 2 numbers between 0-9.


   }
}
