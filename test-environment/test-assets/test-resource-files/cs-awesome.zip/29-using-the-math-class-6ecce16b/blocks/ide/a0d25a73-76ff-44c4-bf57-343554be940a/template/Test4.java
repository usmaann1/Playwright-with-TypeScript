public class Test4
{
   public static void main(String[] args)
   {
     System.out.println((int) (Math.random() * 10));
   }
}
