 ![](https://www.codingrooms.com/images/courses/csawesome/_images/time45.png ",,NaN")

# 3.7. Comparing Objects

\
Comparing objects is a little different than comparing primitive typed values like numbers. Objects can be very complex and have many attribute values or instance variables inside them. For example, the turtle objects have many instance variables like name, width, height, xPos, yPos, etc. When comparing two turtle objects, we need a specially written **equals** method to compare all of these values. In this lesson, we will take a look at String objects and how they are compared with == vs. the equals method.

## 3.7.1. String Equality

\
The **equals** method for Strings compares two strings letter by letter. `s1.equals(s2)` is true if s1 and s2 have all the same characters in the same order. With Strings and other objects, you almost always use equals instead of == to check their equality.

\
When the operator `==` is used to compare object variables, it returns true when the two variables *refer to the same object*. These variables are called **object references** and **aliases** for the same object. With strings this happens when one string variable is set to another.

 ![](https://www.codingrooms.com/images/courses/csawesome/_images/stringEquality.png ",,NaN")

Figure 1: String aliases

\
 ![coding exercise](https://www.codingrooms.com/images/courses/csawesome/_images/codingExercise.png "left-icon,,NaN") **Coding Exercise**

If you run the following, what will be printed?

\
[https://www.codingrooms.com/block/ide/3b775ff2-a59f-4e90-a365-929bff953ca9](https://www.codingrooms.com/block/ide/3b775ff2-a59f-4e90-a365-929bff953ca9)

\
\
The following [video](https://www.youtube.com/watch?v=hhYBVgmC-vw) traces through the code above and shows how `==` and `equals` work with String objects in memory.

\
[https://www.codingrooms.com/block/embed/8939791c-9434-4999-ad6e-c65b1f611c93](https://www.codingrooms.com/block/embed/8939791c-9434-4999-ad6e-c65b1f611c93)

\
\
Here’s the representation of memory where s2 and s3 refer to the same String object.

 ![](https://www.codingrooms.com/images/courses/csawesome/_images/s2ands3.jpg ",,NaN")

Figure 2: s2 and s3 are aliases referring to the same String object

## 3.7.2. Equality with New Strings

\
If you use the `new` keyword to create a string, it will always create a new string object. So, even if we create two string objects with new that contain all the same characters in the same order, they will not refer to the same object.

What will the following print?

\
[https://www.codingrooms.com/block/ide/029eff8b-8e0a-42fa-9054-7e9c8e5cad43](https://www.codingrooms.com/block/ide/029eff8b-8e0a-42fa-9054-7e9c8e5cad43)

\
\
Watch the [video below](https://www.youtube.com/watch?v=xZroaSGhgxA) to see how this code works in memory. Since we used the `new` keyword, two different String objects will be created that each have the characters `Hello` in them. So `s1 == s2` will be false since they don’t refer to the same object, but `s1.equals(s2)` is true since the two different objects contain the same characters in the same order.

\
[https://www.codingrooms.com/block/embed/ca5c0650-dd81-4a0b-bb5f-f1d93a061770](https://www.codingrooms.com/block/embed/ca5c0650-dd81-4a0b-bb5f-f1d93a061770)

\
\
Here is the representation of these String objects in memory.

 ![](https://www.codingrooms.com/images/courses/csawesome/_images/s1ands2.jpg ",,NaN")

Figure 3: Two strings that are equal with equals but not with ==.

\
Note that you can also create Strings using string literals instead of new, like `String s = "Hello"`. String literals behave a little differently because they are re-used if they already exist instead of creating a new object. But you should not see questions with string literals and == on the AP exam.

\

:::tip 
Note

Only use `==` with primitive types like int or to test if two strings (or objects) refer to the same object. Use `equals`, not `==`, with strings to test if they are equal letter by letter.

:::

\
\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") **Check your understanding**

\
[https://www.codingrooms.com/block/mc/2a3cee2e-b307-426b-8801-309b7a5da2ea](https://www.codingrooms.com/block/mc/2a3cee2e-b307-426b-8801-309b7a5da2ea)

\
\
[https://www.codingrooms.com/block/mc/664d242b-86dc-4ad9-b491-e9774f30b3a3](https://www.codingrooms.com/block/mc/664d242b-86dc-4ad9-b491-e9774f30b3a3)

\
\
[https://www.codingrooms.com/block/mc/5b627377-efa1-4ee2-8a5d-a80504aeb967](https://www.codingrooms.com/block/mc/5b627377-efa1-4ee2-8a5d-a80504aeb967)

\
## 3.7.3. Comparing with null

\
One common place to use == or != with objects is to compare them to **null** to see if they really exist. Sometimes short-circuit evaluation is used to avoid an error if the object doesn’t exist. Remember that **short-circuit evaluation** is used with && in Java meaning that if the first part of the if condition is false, it doesn’t even have to check the second condition and it knows the whole && test is false.

\
 ![coding exercise](https://www.codingrooms.com/images/courses/csawesome/_images/codingExercise.png "left-icon,,NaN") **Coding Exercise**

Try the following code to see a NullPointer error (if you don’t see the error because of the autograding, you can copy it into the pencil icon scratch area to run it without the grader). Since s is null, indexOf throws an NullPointer error for s. Comment out the first if statement and run the program again. The second if statement avoids the error with shortcircuit evaluation. Because s != null is false, the rest of the boolean expression is not evaluated. Now, change s to set it to “apple” instead of null in the first line and run the code again to see that the if statements can print out that “apple contains an a”.

\
[https://www.codingrooms.com/block/ide/297e3c04-2f35-4eb3-ba3d-9ab44f2bea00](https://www.codingrooms.com/block/ide/297e3c04-2f35-4eb3-ba3d-9ab44f2bea00)

\
\
The [following video](https://www.youtube.com/watch?v=GPdoHm1K8HA) shows how the null string reference works in memory.

\
[https://www.codingrooms.com/block/embed/2c32b0a3-5ca3-4544-9deb-c950c53993e0](https://www.codingrooms.com/block/embed/2c32b0a3-5ca3-4544-9deb-c950c53993e0)

\
## 3.7.4.  ![groupwork](https://www.codingrooms.com/images/courses/csawesome/_images/groupwork.png "left-icon,,NaN") Programming Challenge : Tracing Code

\
What will the following code print out? Trace through the code by drawing diagrams of what is going on in memory like the figures above, and then show the values of s1, s2, s3, s4 and the output after each line of code. Remember that you can use trace tables to track the values of variables as they change throughout a program. To trace through code, write down a variable in each column in a table and keep track of its value throughout the program as you go through it line by line.

```java
String s1 = null;
String s2 = new String("hi");
String s3 = new String("hi");
String s4 = new String("bye");
if (s1 == null)
    s1 = s2;
if (s1 == s2)
   System.out.println("s1 and s2 refer to the same object");
if (s2 == s3)
   System.out.println("s2 and s3 refer to the same object");
if (s3 == s4)
   System.out.println("s3 and s4 refer to the same object");
if (s1.equals(s2) && s2.equals(s3))
    System.out.println("s1, s2, s3 are equal");
```

\
[https://www.codingrooms.com/block/shortanswer/249ad1dd-385e-4549-8e0f-9c0823368fef](https://www.codingrooms.com/block/shortanswer/249ad1dd-385e-4549-8e0f-9c0823368fef)

\
## 3.7.5. Summary

* Often classes have their own **equals** method, which can be used to determine whether two objects of the class are equivalent.
* Two object references are considered **aliases** when they both reference the same object.
* Object reference values can be compared, using == and !=, to identify aliases.
* A reference value can be compared with null, using == or !=, to determine if the reference actually references an object.

## 3.7.6. AP Practice

\
[https://www.codingrooms.com/block/mc/3d0747d9-40ba-4f2c-867b-037bdf7c08f6](https://www.codingrooms.com/block/mc/3d0747d9-40ba-4f2c-867b-037bdf7c08f6)

\
