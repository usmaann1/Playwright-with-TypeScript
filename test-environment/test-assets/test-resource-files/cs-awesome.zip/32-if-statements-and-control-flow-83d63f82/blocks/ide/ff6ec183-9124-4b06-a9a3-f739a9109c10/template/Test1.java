public class Test1
{
   public static void main(String[] args)
   {
     boolean isRaining = true;
     if (isRaining)
     {
        System.out.println("Take an umbrella!");
     }
     System.out.println("Drive carefully");
   }
}
