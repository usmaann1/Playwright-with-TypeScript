public class Test1
{
   public static void main(String[] args)
   {
       boolean isCold = false;
       if (isCold = true);
           System.out.println("Wear a coat");
           System.out.println("Wear gloves");

   }
}
