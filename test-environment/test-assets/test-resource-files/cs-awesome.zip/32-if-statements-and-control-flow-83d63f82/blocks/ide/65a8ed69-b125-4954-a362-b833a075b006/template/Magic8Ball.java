public class Magic8Ball
{
   public static void main(String[] args)
   {
     // Get a random number from 1 to 8

     // Use if statements to test the random number
     // and print out 1 of 8 random responses


   }
}
