
import java.util.Scanner;  // added to allow keyboard input
class Main {
public static void main(String[] args) {
    // Tell the user to enter a question
    Scanner scan = new Scanner(System.in);
    System.out.println("Welcome to the Magic 8 Ball!");
    System.out.print("Enter your question and I will answer it: ");
    String question = scan.nextLine();

    // Get a random number from 1 to 8

    // Use if statements to print out 1 of 8 responses




    }
}
