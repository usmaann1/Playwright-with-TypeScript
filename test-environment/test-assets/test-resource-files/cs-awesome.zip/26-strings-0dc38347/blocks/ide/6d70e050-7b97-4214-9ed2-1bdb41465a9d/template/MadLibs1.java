public class MadLibs1
{
   public static void main(String[] args)
   {
     // fill these in with silly words/strings (don't read the poem yet)
     String pluralnoun1 =
     String color1 =
     String color2 =
     String food =
     String pluralnoun2 =


     // Run to see the silly poem!
     System.out.println("Roses are " + color1);
     System.out.println(pluralnoun1 + " are " + color2);
     System.out.println("I like " + food);
     System.out.println("Do " + pluralnoun2 + " like them too?");

     // Now come up with your own silly poem!

   }
}
