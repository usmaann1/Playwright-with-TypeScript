public class StringTest
{
   public static void main(String[] args)
   {
       String greeting1 = "Hello!";
       String greeting2 = new String("Welcome!");
       System.out.println(greeting1);
       System.out.println(greeting2);
    }
 }
 