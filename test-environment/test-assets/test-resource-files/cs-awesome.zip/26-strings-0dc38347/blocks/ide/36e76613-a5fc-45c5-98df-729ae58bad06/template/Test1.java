public class Test1
{
   public static void main(String[] args)
   {
     String greeting = null;
     System.out.println(greeting);
   }
}
