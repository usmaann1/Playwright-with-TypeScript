public class Test2
{
   public static void main(String[] args)
   {
     String message = "12" + 4 + 3;
     System.out.println(message);
   }
}
