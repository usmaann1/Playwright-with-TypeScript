public class TestEscape
{
   public static void main(String[] args)
   {
     String message = "Here is a backslash quote \" " +
       " and a backslashed backslash (\\) " +
       "Backslash n \n prints out a new line.";
     System.out.println(message);
   }
}
