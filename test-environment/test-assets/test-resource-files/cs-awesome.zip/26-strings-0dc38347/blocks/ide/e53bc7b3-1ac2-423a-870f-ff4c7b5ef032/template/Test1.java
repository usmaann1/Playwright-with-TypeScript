public class Test1
{
   public static void main(String[] args)
   {
       String start = "Happy Birthday";
       String name = "Jose";
       String result = start + " " + name;  // add together strings
       result += "!"; // add on to the same string
       System.out.println(result);
   }
}
