 ![](https://www.codingrooms.com/images/courses/csawesome/_images/time45.png ",,NaN")

# 2.6. Strings

\
**Strings** in Java are objects of the `String` class that hold sequences of characters (a, b, c, $, etc). Remember that a class (or classification) in Java defines the data that all objects of the class have (the fields) and the behaviors, the things that objects know how to do (the methods).

\
You can declare a variable to be of type `String`.

\

:::tip 
Note

Class names in Java, like `String`, begin with a capital letter. All primitive types: `int`, `double`, and `boolean`, begin with a lowercase letter. This is one easy way to tell the difference between primitive types and class types.

:::

\
Run the following code. What does it print?

\
[https://www.codingrooms.com/block/ide/36e76613-a5fc-45c5-98df-729ae58bad06](https://www.codingrooms.com/block/ide/36e76613-a5fc-45c5-98df-729ae58bad06)

\
\
The code above declares an object variable named `greeting` and sets the value of greeting to the Java keyword `null` to show that it doesn’t refer to any object yet. So `System.out.println(greeting);` will print `null`.

\
Object variables **refer** to objects in memory. A reference is a way to find the actual object, like adding a contact to your phone lets you reach someone without knowing exactly where they are. The value of greeting is null since the string object has not been created yet.

 ![](https://www.codingrooms.com/images/courses/csawesome/_images/greeting.png ",,NaN")

Figure 1: Initial value for an object reference

\
In Java there are two ways to create an object of the `String` class. You can use the `new` keyword followed by a space and then the class constructor and then in parentheses you can include values used to initialize the fields of the object. This is the standard way to create a new object of a class in Java.

```java
String greeting = new String("Hello");
```

\
In Java you can also use just a **string literal**, which is a set of characters enclosed in double quotes (`"`), to create a `String` object.

```java
String greeting = "Hello";
```

\
In both cases an object of the `String` class will be created in memory and the value of the variable greeting will be set to an object reference, a way to find that object.

\
 ![coding exercise](https://www.codingrooms.com/images/courses/csawesome/_images/codingExercise.png "left-icon,,NaN") **Coding Exercise:**

Here is an active code sample that creates two greeting strings: one using a string literal and the other using new and the String constructor. Change the code to add 2 new strings called firstname and lastname, one using a string literal and the other using new, and print them out with the greetings.

\
[https://www.codingrooms.com/block/ide/585509d6-3d94-4429-8e57-caa9504e8ddd](https://www.codingrooms.com/block/ide/585509d6-3d94-4429-8e57-caa9504e8ddd)

\
Now that greeting refers to an actual object we can ask the object what class created it. Try the following. What does it print?

\
[https://www.codingrooms.com/block/ide/61a0b056-4bc7-47d8-b869-f02ef0aa509f](https://www.codingrooms.com/block/ide/61a0b056-4bc7-47d8-b869-f02ef0aa509f)

\
\
The code above will first print `class java.lang.String` since `greeting` was created by the `String` class. The full name for the `String` class is `java.lang.String`. The `java.lang` part is the **package** name. Every class in the Java language is in a package and the standard classes like `String` are in the `java.lang` package. Every object in Java knows the class that created it. Also, every class knows its **parent** class. Yes, a class can have a parent class, just as people have parents. But, in Java a class can only have one parent. A class can `inherit` object fields and methods from a parent class, just like you might inherit musical ability from a parent. The fourth line will print `class java.lang.Object` because the parent class (**superclass**) of the String class is the Object class. All classes in Java inherit from the Object class at some point in their ancestry.

 ![](https://www.codingrooms.com/images/courses/csawesome/_images/stringObject.png ",,NaN")

Figure 2: Object variable of type String with a reference to a String object which has a reference to the String class which has a reference to the Object class.

## 2.6.1. String Operators - Concatenation

\
Strings can be **appended** to each other to create a new string using the `+` or `+=` operator . This is also called **concatenation**.

Try the following code. Add another variable for a lastname that is “Hernandez”. Use += or + to add the lastname variable after name to the result. Use += or + to add 2 more exclamation points (!) to the end of the happy birthday greeting in result.

\
[https://www.codingrooms.com/block/ide/e53bc7b3-1ac2-423a-870f-ff4c7b5ef032](https://www.codingrooms.com/block/ide/e53bc7b3-1ac2-423a-870f-ff4c7b5ef032)

\
\

:::tip 
Note

Note that spaces are not added between strings automatically. If you want a space between two strings then add one using + ” ” +. If you forget to add spaces, you will get smushed output like “HiJose” instead of “Hi Jose”. And remember that variables are never put inside the quotes (“”) since this would print the variable name out letter by letter instead of its value.

:::

\
\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") **Check Your Understanding**

\
[https://www.codingrooms.com/block/mc/15dc815e-c98c-42ff-9e25-13d404485817](https://www.codingrooms.com/block/mc/15dc815e-c98c-42ff-9e25-13d404485817)

\
\
You can even add other items to a string using the `+` operator. The other item will be converted to a string using the `toString` operator if it is an object and then appended to the current string. All objects inherit a `toString` method that returns a string representation of the object.

\
 ![coding exercise](https://www.codingrooms.com/images/courses/csawesome/_images/codingExercise.png "left-icon,,NaN") **Coding Exercise:**

What do you think the following will print? Guess before you hit run. If you want the addition to take place before the numbers are turned into a string what should you do? Try to modify the code so that it adds 4 + 3 before appending the value to the string. Hint: you used this to do addition before multiplication in arithmetic expressions.

\
[https://www.codingrooms.com/block/ide/0923d820-02e0-49be-80f4-4e6f6045d751](https://www.codingrooms.com/block/ide/0923d820-02e0-49be-80f4-4e6f6045d751)

\
\

:::tip 
Note

If you are appending a number to a string it will be converted to a string first before being appended.

:::

\
\
Since the same operators are processed from left to right this will print `1243`. First 4 will be turned into a string and appended to 12 and then 3 will be turned into a string and appended to 124. If you want to do addition instead, try using parentheses!

\
What if you wanted to print out a double quote ” character? Since the double quote ” is a special character with meaning in Java, we put in a backslash in front of the quote to signal that we want just the character. This is called a **backslash escape sequence**. And if you wanted to print out a backslash, you would have to backslash it too in order to escape its special meaning. Another useful backslashed character is backslash \\n which will put in a newline.

Here are the escape sequences that may be used in the AP course.

\
[https://www.codingrooms.com/block/ide/a4ac19d6-62e0-42be-984e-aa465e795197](https://www.codingrooms.com/block/ide/a4ac19d6-62e0-42be-984e-aa465e795197)

\
## 2.6.2.  ![groupwork](https://www.codingrooms.com/images/courses/csawesome/_images/groupwork.png "left-icon,,NaN") Programming Challenge : Mad Libs

\
Have you ever played MAD LIBS? In this game, you first choose a bunch of words without looking at the story and then those words are filled into the story to make it sound very wacky! Fill in the variables below with Strings for each word, and then run to see the wacky story.

\
Then, working in pairs, come up with another silly story that uses at least 5 new String variables. When you’re done, try another team’s mad libs code.

If you used another Coding Rooms Workspace for this challenge, copy the url of your workspace here to turn in.

\
[https://www.codingrooms.com/block/ide/6d70e050-7b97-4214-9ed2-1bdb41465a9d](https://www.codingrooms.com/block/ide/6d70e050-7b97-4214-9ed2-1bdb41465a9d)

\
## 2.6.3. Summary

* **Strings** in Java are objects of the `String` class that hold sequences of characters.
* String objects can be created by using string literals (String s = “hi”;) or by calling the String class constructor (String t = new String(“bye”);).
* **new** is used to create a new object of a class.
* **null** is used to indicate that an object reference doesn’t refer to any object yet.
* String objects can be concatenated using the + or += operator, resulting in a new String object.
* Primitive values can be concatenated with a String object. This causes implicit conversion of the values to String objects.
* Escape sequences start with a backslash \\ and have special meaning in Java. Escape sequences used in this course include ", \\, and \\n to print out a quote, backslash, and a new line.