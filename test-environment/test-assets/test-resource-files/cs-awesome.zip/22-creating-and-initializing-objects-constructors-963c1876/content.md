 ![](https://www.codingrooms.com/images/courses/csawesome/_images/time45.png ",,NaN")

# 2.2. Creating and Initializing Objects: Constructors

\
A Java class defines what objects of the class know (attributes) and what they can do (behaviors). Each class has **constructors** like `World()` and `Turtle(habitat)` which are used to initialize the attributes in a newly created object.

\
A new object is created with the `new` keyword followed by the class name (`new Class()`). When this code executes, it creates a new object of the specified class and calls a constructor, which has the same name as the class. For example, `new World()` creates and initializes a new object of the `World` class, and `new Turtle(habitat)` creates and initializes a new `Turtle` object in the World habitat.

```java
// To create a new object and call a constructor write:
// ClassName variableName = new ClassName(parameters);
World habitat = new World();    // create a new World object
Turtle t = new Turtle(habitat); // create a new Turtle object
```

## 2.2.1. Overloading Constructors

\
There can be more than one constructor defined in a class. This is called **overloading** the constructor. There is usually a constructor that has no parameters (nothing inside the parentheses following the name of the constructor) like the `World()` constructor above. This is also called the **no-argument constructor**. The **no-argument** constructor usually sets the attributes of the object to default values.

\
There can also be other constructors that take parameters like the `Turtle(habitat)` constructor call above. A **parameter** (also called **actual parameter** or **argument**) is a value that is passed into a constructor. It can be used to initialize the attribute of an object.

\
The `World` class actually has 2 constructors. One doesn’t take any parameters and one takes the world’s width and height.

 ![Two overloaded World constructors](https://www.codingrooms.com/images/courses/csawesome/_images/worldConstructors.png ",,NaN")

Figure 1: Two overloaded World constructors

\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") **Check your understanding**

\
[https://www.codingrooms.com/block/mc/ba92b591-b373-4465-9cfd-4ced44d0966d](https://www.codingrooms.com/block/mc/ba92b591-b373-4465-9cfd-4ced44d0966d)

\
\
[https://www.codingrooms.com/block/mc/1b06f785-768b-4498-8bbe-1e7e8ae2c3b9](https://www.codingrooms.com/block/mc/1b06f785-768b-4498-8bbe-1e7e8ae2c3b9)

\
## 2.2.2. The World Class Constructors

\
The constructor that doesn’t take any parameters, `World()`, creates a graphical window with 640x480 pixels. The `World(int width, int height)` constructor takes two integer parameters, and initializes the `World` object’s width and height to them, for example `new World(300,400)` creates a 300x400 pixel world.

```java
World world1 = new World(); // creates a 640x480 world
World world2 = new World(300,400); // creates a 300x400 world
```

\

:::tip 
Note

The turtle world does not use the cartesian coordinate system. The top left corner is (0,0), x increases to the right, and y increases towards the bottom of the page.

:::

\
 ![](https://www.codingrooms.com/images/courses/csawesome/_images/coords.png ",,NaN")

Figure 2: The coordinate (0,0) is at the top left of the Turtle world.

## 2.2.3. The Turtle Class Constructors

\
The `Turtle` class also has multiple constructors, although it always requires a world as a parameter in order to have a place to draw the turtle. The default location for the turtle is right in the middle of the world.

\
There is another `Turtle` constructor that places the turtle at a certain (x,y) location in the world, for example at the coordinate (50, 100) below.

```java
Turtle t1 = new Turtle(world1);
Turtle t2 = new Turtle(50, 100, world1);
```

\

:::tip 
Note

Notice that the order of the parameters matter. The `Turtle` constructor takes `(x,y,world)` as parameters in that order. If you mix up the order of the parameters it will cause an error, because the parameters will not be the data types that it expects. This is one reason why programming languages have data types – to allow for error-checking.

:::

\
\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") **Check your understanding**

\
[https://www.codingrooms.com/block/mc/eed3b674-585d-4a0a-8d41-6b03a98f8cbd](https://www.codingrooms.com/block/mc/eed3b674-585d-4a0a-8d41-6b03a98f8cbd)

\
\
 ![coding exercise](https://www.codingrooms.com/images/courses/csawesome/_images/codingExercise.png "left-icon,,NaN") **Coding Exercise:**

Try changing the code below to create a `World` object with 300x400 pixels. Where is the turtle placed by default? What parameters do you need to pass to the `Turtle` constructor to put the turtle at the top right corner? Experiment and find out. What happens if you mix up the order of the parameters?

\
[https://www.codingrooms.com/block/ide/a55b61c1-92cb-4386-9124-dc470db0bbce](https://www.codingrooms.com/block/ide/a55b61c1-92cb-4386-9124-dc470db0bbce)

\
## 2.2.4. Object Variables and References

\
You can also declare an **object variable** and initialize it to **null** (`Turtle t1 = null;`). An object variable holds a **reference** to an object. A **reference** is a way to find the object in memory. It is like a tracking number that you can use to track the location of a package.

\
Watch the [video](https://www.youtube.com/watch?v=5fpjgXAV2BU&list=PLHqz-wcqDQIEP6p1_0wOb9l9aQ0qFijrP&ab_channel=colleenlewis) below about null.

\
[https://www.codingrooms.com/block/embed/e65096b0-01f3-4714-b2f0-e6e6948ee946](https://www.codingrooms.com/block/embed/e65096b0-01f3-4714-b2f0-e6e6948ee946)

\
\
The code `Turtle t1 = null;` creates a variable `t1` that refers to a `Turtle` object, but the `null` means that it doesn’t refer to an object yet. You could later create the object and set the object variable to refer to that new object (`t1 = new Turtle(world1)`). Or more commonly, you can declare an object variable and initialize it in the same line of code (`Turtle t2 = new Turtle(world1);`).

```java
World world1 = new World();
Turtle t1 = null;
t1 = new Turtle(world1);
// declare and initialize t2
Turtle t2 = new Turtle(world1);
```

## 2.2.5. Constructor Signatures

\
When you use a class that someone has already written for you in a **library** that you can import like the `Turtle` class above, you can look up how to use the constructors and methods in the [documentation](https://www2.cs.uic.edu/\~i101/doc/Turtle.html) for that class. The documentation will list the **signatures** (or headers) of the constructors or methods which will tell you their name and parameter list. The **parameter list**, in the **header** of a constructor, lists the **formal parameters**, declaring the variables that will be passed in as values and their data types.

\
Constructors are **overloaded** when there are multiple constructors, but the constructors have different signatures. They can differ in the number, type, and/or order of parameters. For example, here are two constructors for the `Turtle` class that take different parameters:

 ![Turtle Class Constructor Signatures and Parameters](https://www.codingrooms.com/images/courses/csawesome/_images/TurtleClassDefn.png ",,NaN")

Figure 3: Turtle Class Constructor Signatures and Parameters

\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") **Check your understanding**

\
[https://www.codingrooms.com/block/mc/bf8dcb7b-541c-4f5d-90e2-d2909b0b4fdb](https://www.codingrooms.com/block/mc/bf8dcb7b-541c-4f5d-90e2-d2909b0b4fdb)

\
\
[https://www.codingrooms.com/block/mc/a50ba13f-7e26-4d22-8bf4-fad9b8d86abd](https://www.codingrooms.com/block/mc/a50ba13f-7e26-4d22-8bf4-fad9b8d86abd)

\
\
In Unit 5, you will learn to write your own classes. However, if you see a class definition on the AP exam, like the one below for a class called `Date`, you should be able to pick out the attributes (instance variables) and the constructors and know how to use them.

 ![A Date class showing attributes and constructors](https://www.codingrooms.com/images/courses/csawesome/_images/DateClass.png ",,NaN")

Figure 4: A Date class showing attributes and constructors

\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") **Check your understanding**

\
[https://www.codingrooms.com/block/clickable/c32b01d0-21f1-4583-859d-06fe144f178d](https://www.codingrooms.com/block/clickable/c32b01d0-21f1-4583-859d-06fe144f178d)

\
\
[https://www.codingrooms.com/block/mc/3daaacf6-0f36-4762-9fa7-9a41cd40a7cc](https://www.codingrooms.com/block/mc/3daaacf6-0f36-4762-9fa7-9a41cd40a7cc)

\
## 2.2.6. Formal and Actual Parameters

\
When a constructor like `Date(2005,9,1)` is called, the **formal parameters**, (year, month, day), are set to copies of the **actual parameters** (or **arguments**), which are (2005,9,1). This is **call by value** which means that copies of the actual parameter values are passed to the constructor. These values are used to initialize the object’s attributes.

 ![Parameter Mapping](https://www.codingrooms.com/images/courses/csawesome/_images/parameterMappingDate.png ",,NaN")

Figure 5: Parameter Mapping

\
The type of the values being passed in as arguments have to match the type of the formal parameter variables. We cannot give a constructor a `String` object when it is expecting an `int`. The order of the arguments also matters. If you mix up the month and the day in the `Date` constructor, you will get a completely different date, for example January 9th (1/9) instead of Sept. 1st (9/1).

\
 ![exercise](https://www.codingrooms.com/images/courses/csawesome/_images/exercise.png "left-icon,,NaN") **Check your understanding**

\
[https://www.codingrooms.com/block/mc/63b57221-4aba-4b9b-9b8d-4469944a6c4f](https://www.codingrooms.com/block/mc/63b57221-4aba-4b9b-9b8d-4469944a6c4f)

\
\
[https://www.codingrooms.com/block/mc/88c05ca9-12c2-42fa-a631-fc77777c0748](https://www.codingrooms.com/block/mc/88c05ca9-12c2-42fa-a631-fc77777c0748)

\
\
This lesson introduces a lot of vocabulary, but don’t worry if you don’t understand everything about classes and constructors yet. You will learn more about how this all works in Unit 5 when you write your own classes and constructors. And you will see parameters again with methods in the next lessons.

 ![](https://www.codingrooms.com/images/courses/csawesome/_images/customTurtles.png ",,NaN")

## 2.2.7.  ![groupwork](https://www.codingrooms.com/images/courses/csawesome/_images/groupwork.png "left-icon,,NaN") Programming Challenge: Custom Turtles

\
Working in pairs, you will now look at a new class called CustomTurtle and design some colorful turtles with its constructors.

\
First, as a warm up, do the following debugging exercise.

Debug the following code.

\
[https://www.codingrooms.com/block/ide/8f203600-d638-468c-b676-5a873c23da41](https://www.codingrooms.com/block/ide/8f203600-d638-468c-b676-5a873c23da41)

\
\
The CustomTurtle class in the ActiveCode below inherits many of its attributes and methods from the Turtle class (you will learn more about inheritance in Unit 9). However, it has some new constructors with more parameters to customize a turtle with its body color, shell color, width, and height. CustomTurtle has 3 constructors:

```java
/** Constructs a CustomTurtle in the middle of the world */
public CustomTurtle(World w)

/** Constructs a CustomTurtle with a specific body color,
    shell color, and width and height in the middle of the world */
public CustomTurtle(World w, Color body, Color shell, int w, int h)

/** Constructs a CustomTurtle with a specific body color,
    shell color, and width and height at position (x,y) in the world */
public CustomTurtle(int x, int y, World w, Color body, Color shell, int w, int h)
```

\
You will use the constructor(s) to create the CustomTurtles below. You can specify colors like Color.red by using the [Color](https://docs.oracle.com/javase/7/docs/api/java/awt/Color.html) class in Java.

1. Create a large 150x200 (width 150 and height 200) CustomTurtle with a green body (Color.green) and a blue shell (Color.blue) at position (150,300)
2. Create a small 25x50 CustomTurtle with a red body and a yellow shell at position (350,200)
3. Create a CustomTurtle of your own design.

Use the CustomTurtle constructors to create the following turtles.

\
[https://www.codingrooms.com/block/ide/3cb421c0-ba3e-4def-b1d5-7aca0658283f](https://www.codingrooms.com/block/ide/3cb421c0-ba3e-4def-b1d5-7aca0658283f)

\
## 2.2.8. Summary

* **Constructors** initialize the attributes in newly created objects. They have the same name as the class.
* A **constructor signature** is the constructor name followed by the parameter list which is a list of the types of the parameters and the variable names used to refer to them in the constructor.
* **Overloading** is when there is more than one constructor. They must differ in the number, type, or order of parameters.
* **New** is a keyword that is used to create a new object of a class. The syntax is `new ClassName()`. It creates a new object of the specified class and calls a constructor.
* A **no-argument constructor** is a constructor that doesn’t take any passed in values (arguments).
* **Parameters** allow values to be passed to the constructor to initialize the newly created object’s attributes.
* The **parameter list**, in the header of a constructor, is a list of the type of the value being passed and a variable name. These variables are called the **formal parameters**.
* **Actual parameters** are the values being passed to a constructor. The formal parameters are set to a copy of the value of the actual parameters.
* **Formal parameters** are the specification of the parameters in the constructor header. In Java this is a list of the type and name for each parameter (`World(int width, int height`).
* **Call by value** means that when you pass a value to a constructor or method it passes a copy of the value.

## 2.2.9. AP Practice

\
[https://www.codingrooms.com/block/mc/39401663-0801-4390-99bc-b1d474fed139](https://www.codingrooms.com/block/mc/39401663-0801-4390-99bc-b1d474fed139)

\
\
[https://www.codingrooms.com/block/mc/803be63f-5d1d-46e5-bc68-18fab8d71b6d](https://www.codingrooms.com/block/mc/803be63f-5d1d-46e5-bc68-18fab8d71b6d)

\
