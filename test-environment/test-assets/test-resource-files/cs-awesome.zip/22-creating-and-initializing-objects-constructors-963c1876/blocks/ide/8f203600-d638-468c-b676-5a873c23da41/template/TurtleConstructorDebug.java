import java.util.*;
import java.awt.*;

public class TurtleConstructorDebug
{
  public static void main(String[] args)
  {
      World w = new World(300,0);
      turtle t0;
      Turtle t1 = new Turtle();
      Turtle t2 = new Turtle(world, 100, 50)
      t0.forward();
      t1.turnRight();
      t2.turnLeft();
      world.show(true);
  }
}
